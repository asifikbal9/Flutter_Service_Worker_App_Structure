import 'wallet_transaction.dart';

class Wallet {
  final int workerId;

  final double todayEarnings;

  final double availableBalance;

  final double pendingBalance;

  final double bonusEarned;

  final double lifetimeEarnings;

  final double totalWithdrawn;

  final double monthlyEarnings;

  final double monthlyGoal;

  final int rewardPoints;

  final int completedJobs;

  final int completedBonusJobs;

  final double rating;

  final String tier;

  final int streakDays;

  final int cancelledJobs;

  final int rejectedJobs;

  final int lateArrivals;

  final DateTime? lastWithdrawalDate;

  final List<WalletTransaction> transactions;

  const Wallet({
    required this.workerId,
    required this.todayEarnings,
    required this.availableBalance,
    required this.pendingBalance,
    required this.bonusEarned,
    required this.lifetimeEarnings,
    required this.totalWithdrawn,
    required this.monthlyEarnings,
    required this.monthlyGoal,
    required this.rewardPoints,
    required this.completedJobs,
    required this.completedBonusJobs,
    required this.rating,
    required this.tier,
    required this.streakDays,
    required this.cancelledJobs,
    required this.rejectedJobs,
    required this.lateArrivals,
    required this.lastWithdrawalDate,
    required this.transactions,
  });

  Wallet copyWith({
    int? workerId,
    double? todayEarnings,
    double? availableBalance,
    double? pendingBalance,
    double? bonusEarned,
    double? lifetimeEarnings,
    double? totalWithdrawn,
    double? monthlyEarnings,
    double? monthlyGoal,
    int? rewardPoints,
    int? completedJobs,
    int? completedBonusJobs,
    double? rating,
    String? tier,
    int? streakDays,
    int? cancelledJobs,
    int? rejectedJobs,
    int? lateArrivals,
    DateTime? lastWithdrawalDate,
    List<WalletTransaction>? transactions,
  }) {
    return Wallet(
      workerId: workerId ?? this.workerId,
      todayEarnings:
      todayEarnings ?? this.todayEarnings,
      availableBalance:
      availableBalance ??
          this.availableBalance,
      pendingBalance:
      pendingBalance ??
          this.pendingBalance,
      bonusEarned:
      bonusEarned ?? this.bonusEarned,
      lifetimeEarnings:
      lifetimeEarnings ??
          this.lifetimeEarnings,
      totalWithdrawn:
      totalWithdrawn ??
          this.totalWithdrawn,
      monthlyEarnings:
      monthlyEarnings ??
          this.monthlyEarnings,
      monthlyGoal:
      monthlyGoal ?? this.monthlyGoal,
      rewardPoints:
      rewardPoints ?? this.rewardPoints,
      completedJobs:
      completedJobs ??
          this.completedJobs,
      completedBonusJobs:
      completedBonusJobs ??
          this.completedBonusJobs,
      rating: rating ?? this.rating,
      tier: tier ?? this.tier,
      streakDays:
      streakDays ?? this.streakDays,
      cancelledJobs:
      cancelledJobs ??
          this.cancelledJobs,
      rejectedJobs:
      rejectedJobs ??
          this.rejectedJobs,
      lateArrivals:
      lateArrivals ??
          this.lateArrivals,
      lastWithdrawalDate:
      lastWithdrawalDate ??
          this.lastWithdrawalDate,
      transactions:
      transactions ??
          this.transactions,
    );
  }

  double get totalBalance =>
      availableBalance + pendingBalance;

  double get totalEarned =>
      lifetimeEarnings + bonusEarned;

  double get monthlyProgress {
    if (monthlyGoal <= 0) {
      return 0;
    }

    return (monthlyEarnings /
        monthlyGoal)
        .clamp(0.0, 1.0);
  }

  int get performanceScore {
    return rewardPoints +
        (completedJobs * 10) +
        (completedBonusJobs * 20) -
        (cancelledJobs * 15) -
        (lateArrivals * 10);
  }

  bool get isBronze =>
      tier.toLowerCase() == 'bronze';

  bool get isSilver =>
      tier.toLowerCase() == 'silver';

  bool get isGold =>
      tier.toLowerCase() == 'gold';

  bool get isPlatinum =>
      tier.toLowerCase() == 'platinum';

  bool get isDiamond =>
      tier.toLowerCase() == 'diamond';

  bool get canWithdraw =>
      availableBalance >= 100;

  bool get eligibleForExtraBonus =>
      streakDays >= 7 &&
          rating >= 4.5 &&
          cancelledJobs == 0;

  String get nextTier {
    switch (tier.toLowerCase()) {
      case 'bronze':
        return 'Silver';

      case 'silver':
        return 'Gold';

      case 'gold':
        return 'Platinum';

      case 'platinum':
        return 'Diamond';

      default:
        return 'Top Tier Achieved';
    }
  }
}