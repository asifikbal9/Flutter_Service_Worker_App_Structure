import 'package:flutter/material.dart';

class ActivityItem {
  final int id;

  final String title;

  final String subtitle;

  final DateTime createdAt;

  final IconData icon;

  final Color color;

  const ActivityItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.createdAt,
    required this.icon,
    required this.color,
  });

  ActivityItem copyWith({
    int? id,
    String? title,
    String? subtitle,
    DateTime? createdAt,
    IconData? icon,
    Color? color,
  }) {
    return ActivityItem(
      id: id ?? this.id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      createdAt: createdAt ?? this.createdAt,
      icon: icon ?? this.icon,
      color: color ?? this.color,
    );
  }

  String get timeAgo {
    final difference =
    DateTime.now().difference(createdAt);

    if (difference.inMinutes < 1) {
      return 'Just now';
    }

    if (difference.inHours < 1) {
      return '${difference.inMinutes} min ago';
    }

    if (difference.inDays < 1) {
      return '${difference.inHours} hr ago';
    }

    return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
  }
}