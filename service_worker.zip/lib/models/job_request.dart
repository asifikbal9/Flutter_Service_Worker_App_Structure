class JobRequest {
  /// Unique request ID
  final int id;

  /// Service order number
  final String orderNumber;

  /// Customer who placed the booking
  final int customerId;

  final String customerName;

  final String customerPhone;

  /// Whether customer booked for another person
  final bool isForAnotherPerson;

  /// Actual person receiving the service
  final String recipientName;

  final String recipientPhone;

  final String recipientAddress;

  final double recipientLatitude;

  final double recipientLongitude;

  /// Service details
  final String serviceName;

  final String serviceCategory;

  final String serviceDescription;

  final double servicePrice;

  /// Scheduling
  final DateTime bookingDate;

  final DateTime scheduledDate;

  /// Worker assignment
  final int? assignedWorkerId;

  final String? assignedWorkerName;

  /// Job status
  ///
  /// Pending
  /// Accepted
  /// On The Way
  /// Started
  /// Completed
  /// Cancelled
  final String status;

  /// Notes from customer
  final String notes;

  /// Distance to destination
  final double distanceKm;

  /// Estimated arrival time
  final Duration estimatedArrival;

  /// Actual extra time taken
  final Duration extraTimeTaken;

  /// Bonus system
  final bool eligibleForBonus;

  final double bonusAmount;

  /// Completion details
  final bool isCompleted;

  final DateTime? completedAt;

  const JobRequest({
    required this.id,
    required this.orderNumber,
    required this.customerId,
    required this.customerName,
    required this.customerPhone,
    required this.isForAnotherPerson,
    required this.recipientName,
    required this.recipientPhone,
    required this.recipientAddress,
    required this.recipientLatitude,
    required this.recipientLongitude,
    required this.serviceName,
    required this.serviceCategory,
    required this.serviceDescription,
    required this.servicePrice,
    required this.bookingDate,
    required this.scheduledDate,
    required this.assignedWorkerId,
    required this.assignedWorkerName,
    required this.status,
    required this.notes,
    required this.distanceKm,
    required this.estimatedArrival,
    required this.extraTimeTaken,
    required this.eligibleForBonus,
    required this.bonusAmount,
    required this.isCompleted,
    required this.completedAt,
  });

  JobRequest copyWith({
    int? id,
    String? orderNumber,
    int? customerId,
    String? customerName,
    String? customerPhone,
    bool? isForAnotherPerson,
    String? recipientName,
    String? recipientPhone,
    String? recipientAddress,
    double? recipientLatitude,
    double? recipientLongitude,
    String? serviceName,
    String? serviceCategory,
    String? serviceDescription,
    double? servicePrice,
    DateTime? bookingDate,
    DateTime? scheduledDate,
    int? assignedWorkerId,
    String? assignedWorkerName,
    String? status,
    String? notes,
    double? distanceKm,
    Duration? estimatedArrival,
    Duration? extraTimeTaken,
    bool? eligibleForBonus,
    double? bonusAmount,
    bool? isCompleted,
    DateTime? completedAt,
  }) {
    return JobRequest(
      id: id ?? this.id,
      orderNumber: orderNumber ?? this.orderNumber,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      customerPhone: customerPhone ?? this.customerPhone,
      isForAnotherPerson:
      isForAnotherPerson ??
          this.isForAnotherPerson,
      recipientName:
      recipientName ?? this.recipientName,
      recipientPhone:
      recipientPhone ?? this.recipientPhone,
      recipientAddress:
      recipientAddress ??
          this.recipientAddress,
      recipientLatitude:
      recipientLatitude ??
          this.recipientLatitude,
      recipientLongitude:
      recipientLongitude ??
          this.recipientLongitude,
      serviceName:
      serviceName ?? this.serviceName,
      serviceCategory:
      serviceCategory ??
          this.serviceCategory,
      serviceDescription:
      serviceDescription ??
          this.serviceDescription,
      servicePrice:
      servicePrice ?? this.servicePrice,
      bookingDate:
      bookingDate ?? this.bookingDate,
      scheduledDate:
      scheduledDate ?? this.scheduledDate,
      assignedWorkerId:
      assignedWorkerId ??
          this.assignedWorkerId,
      assignedWorkerName:
      assignedWorkerName ??
          this.assignedWorkerName,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      distanceKm:
      distanceKm ?? this.distanceKm,
      estimatedArrival:
      estimatedArrival ??
          this.estimatedArrival,
      extraTimeTaken:
      extraTimeTaken ??
          this.extraTimeTaken,
      eligibleForBonus:
      eligibleForBonus ??
          this.eligibleForBonus,
      bonusAmount:
      bonusAmount ?? this.bonusAmount,
      isCompleted:
      isCompleted ?? this.isCompleted,
      completedAt:
      completedAt ?? this.completedAt,
    );
  }

  bool get isPending =>
      status.toLowerCase() == 'pending';

  bool get isAccepted =>
      status.toLowerCase() == 'accepted';

  bool get isOnTheWay =>
      status.toLowerCase() == 'on the way';

  bool get isStarted =>
      status.toLowerCase() == 'started';

  bool get isCancelled =>
      status.toLowerCase() == 'cancelled';

  bool get canStartJob =>
      isAccepted || isOnTheWay;

  bool get canCompleteJob =>
      isStarted;

  bool get hasBonus =>
      eligibleForBonus &&
          bonusAmount > 0;

  double get totalEarning =>
      servicePrice + bonusAmount;
}