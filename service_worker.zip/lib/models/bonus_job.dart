class BonusJob {
  /// Unique bonus job ID
  final int id;

  /// Display title
  final String title;

  /// Detailed description
  final String description;

  /// Service category
  final String category;

  /// Location
  final String address;

  final double latitude;

  final double longitude;

  /// Distance from worker
  final double distanceKm;

  /// Expected completion duration
  final Duration estimatedDuration;

  /// Bonus amount awarded
  final double bonusAmount;

  /// Reward points awarded
  final int rewardPoints;

  /// Time-sensitive expiry
  final DateTime expiresAt;

  /// Assigned worker
  final int? assignedWorkerId;

  final String? assignedWorkerName;

  /// Status
  ///
  /// Available
  /// Accepted
  /// In Progress
  /// Completed
  /// Expired
  /// Cancelled
  final String status;

  /// Acceptance information
  final DateTime? acceptedAt;

  /// Start information
  final DateTime? startedAt;

  /// Completion information
  final DateTime? completedAt;

  /// Bonus payout information
  final bool bonusPaid;

  final DateTime? bonusPaidAt;

  /// Requirements
  final bool requiresVerification;

  final String verificationType;

  /// Optional notes
  final String notes;

  const BonusJob({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.distanceKm,
    required this.estimatedDuration,
    required this.bonusAmount,
    required this.rewardPoints,
    required this.expiresAt,
    required this.assignedWorkerId,
    required this.assignedWorkerName,
    required this.status,
    required this.acceptedAt,
    required this.startedAt,
    required this.completedAt,
    required this.bonusPaid,
    required this.bonusPaidAt,
    required this.requiresVerification,
    required this.verificationType,
    required this.notes,
  });

  BonusJob copyWith({
    int? id,
    String? title,
    String? description,
    String? category,
    String? address,
    double? latitude,
    double? longitude,
    double? distanceKm,
    Duration? estimatedDuration,
    double? bonusAmount,
    int? rewardPoints,
    DateTime? expiresAt,
    int? assignedWorkerId,
    String? assignedWorkerName,
    String? status,
    DateTime? acceptedAt,
    DateTime? startedAt,
    DateTime? completedAt,
    bool? bonusPaid,
    DateTime? bonusPaidAt,
    bool? requiresVerification,
    String? verificationType,
    String? notes,
  }) {
    return BonusJob(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      distanceKm: distanceKm ?? this.distanceKm,
      estimatedDuration:
      estimatedDuration ?? this.estimatedDuration,
      bonusAmount: bonusAmount ?? this.bonusAmount,
      rewardPoints: rewardPoints ?? this.rewardPoints,
      expiresAt: expiresAt ?? this.expiresAt,
      assignedWorkerId:
      assignedWorkerId ?? this.assignedWorkerId,
      assignedWorkerName:
      assignedWorkerName ?? this.assignedWorkerName,
      status: status ?? this.status,
      acceptedAt: acceptedAt ?? this.acceptedAt,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      bonusPaid: bonusPaid ?? this.bonusPaid,
      bonusPaidAt: bonusPaidAt ?? this.bonusPaidAt,
      requiresVerification:
      requiresVerification ?? this.requiresVerification,
      verificationType:
      verificationType ?? this.verificationType,
      notes: notes ?? this.notes,
    );
  }

  // ==================================================
  // Status Helpers
  // ==================================================

  bool get isAvailable =>
      status.toLowerCase() == 'available';

  bool get isAccepted =>
      status.toLowerCase() == 'accepted';

  bool get isInProgress =>
      status.toLowerCase() == 'in progress';

  bool get isCompleted =>
      status.toLowerCase() == 'completed';

  bool get isExpired =>
      status.toLowerCase() == 'expired';

  bool get isCancelled =>
      status.toLowerCase() == 'cancelled';

  // ==================================================
  // Time Helpers
  // ==================================================

  bool get hasExpired =>
      DateTime.now().isAfter(expiresAt);

  Duration get timeRemaining {
    final remaining =
    expiresAt.difference(DateTime.now());

    return remaining.isNegative
        ? Duration.zero
        : remaining;
  }

  Duration? get completionDuration {
    if (startedAt == null ||
        completedAt == null) {
      return null;
    }

    return completedAt!.difference(startedAt!);
  }

  // ==================================================
  // Worker Actions
  // ==================================================

  bool get canAccept =>
      isAvailable && !hasExpired;

  bool get canStart =>
      isAccepted;

  bool get canComplete =>
      isInProgress;

  // ==================================================
  // Bonus Eligibility
  // ==================================================

  bool get canClaimBonus =>
      isCompleted && !bonusPaid;

  bool get needsVerification =>
      requiresVerification;

  // ==================================================
  // Dashboard Compatibility Getters
  // ==================================================

  /// Alias for bonusAmount.
  /// Some widgets expect rewardAmount.
  double get rewardAmount =>
      bonusAmount;

  /// Alias for rewardPoints.
  int get points =>
      rewardPoints;

  /// Alias for bonusAmount.
  double get totalEarnings =>
      bonusAmount;

  /// Returns completion percentage.
  double get progress {
    if (isCompleted) {
      return 1.0;
    }

    if (isInProgress) {
      return 0.75;
    }

    if (isAccepted) {
      return 0.50;
    }

    if (isAvailable) {
      return 0.25;
    }

    return 0.0;
  }

  /// Human-readable status.
  String get displayStatus {
    switch (status.toLowerCase()) {
      case 'available':
        return 'Available';

      case 'accepted':
        return 'Accepted';

      case 'in progress':
        return 'In Progress';

      case 'completed':
        return 'Completed';

      case 'expired':
        return 'Expired';

      case 'cancelled':
        return 'Cancelled';

      default:
        return status;
    }
  }
}