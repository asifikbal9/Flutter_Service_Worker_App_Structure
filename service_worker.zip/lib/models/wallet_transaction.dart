class WalletTransaction {
  final int id;

  final String title;

  final String description;

  final double amount;

  /// credit / debit
  final String type;

  final DateTime createdAt;

  final int? relatedJobId;

  const WalletTransaction({
    required this.id,
    required this.title,
    required this.description,
    required this.amount,
    required this.type,
    required this.createdAt,
    this.relatedJobId,
  });

  WalletTransaction copyWith({
    int? id,
    String? title,
    String? description,
    double? amount,
    String? type,
    DateTime? createdAt,
    int? relatedJobId,
  }) {
    return WalletTransaction(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt,
      relatedJobId: relatedJobId ?? this.relatedJobId,
    );
  }

  bool get isCredit =>
      type.toLowerCase() == 'credit';

  bool get isDebit =>
      type.toLowerCase() == 'debit';
}