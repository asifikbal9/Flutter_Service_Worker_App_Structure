import 'package:flutter/material.dart';

import '../mock/demo_active_jobs.dart';
import '../mock/demo_job_requests.dart';
import '../models/active_job.dart';
import '../models/job_request.dart';

class JobsProvider extends ChangeNotifier {
  List<JobRequest> _pendingJobs = [];

  List<ActiveJob> _activeJobs = [];

  bool _isLoading = false;

  String? _errorMessage;

  // =========================
  // Getters
  // =========================

  List<JobRequest> get pendingJobs =>
      List.unmodifiable(_pendingJobs);

  List<ActiveJob> get activeJobs =>
      List.unmodifiable(_activeJobs);

  List<ActiveJob> get completedJobs =>
      _activeJobs
          .where(
            (job) =>
        job.isCompletedStatus,
      )
          .toList();

  List<ActiveJob> get recentCompleted {
    final jobs = List<ActiveJob>.from(
      completedJobs,
    );

    jobs.sort(
          (a, b) => (b.completedAt ??
          DateTime.now())
          .compareTo(
        a.completedAt ??
            DateTime.now(),
      ),
    );

    return jobs.take(5).toList();
  }

  bool get isLoading => _isLoading;

  String? get errorMessage =>
      _errorMessage;

  bool get hasPendingJobs =>
      _pendingJobs.isNotEmpty;


  bool get hasActiveJobs =>
      _activeJobs.any(
            (job) =>
        !job.isCompletedStatus &&
            !job.isRejectedStatus,
      );
  int get pendingCount =>
      _pendingJobs.length;

  int get activeCount =>
      _activeJobs
          .where(
            (job) =>
        !job.isCompletedStatus &&
            !job.isRejectedStatus,
      )
          .length;

  int get completedCount =>
      completedJobs.length;

  double get totalBonus =>
      _activeJobs.fold(
        0,
            (total, job) =>
        total +
            job.bonusAmount,
      );

  double get bonusEarned =>
      completedJobs.fold(
        0,
            (total, job) =>
        total +
            job.bonusAmount,
      );

  double get todayEarnings =>
      completedJobs.fold(
        0,
            (total, job) =>
        total +
            job.totalEarnings,
      );

  // =========================
  // Initialization
  // =========================

  Future<void> initialize() async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 300,
        ),
      );

      _pendingJobs = List.from(
        DemoJobRequests
            .pendingRequests,
      );

      _activeJobs = List.from(
        DemoActiveJobs.activeJobs,
      );

      _errorMessage = null;
    } catch (e) {
      _errorMessage =
      'Failed to load jobs.';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> fetchJobs() async {
    await initialize();
  }

  Future<void> refreshJobs() async {
    await initialize();
  }

  // =========================
  // Pending Job Actions
  // =========================

  Future<void> acceptJob(
      JobRequest request,
      ) async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 300,
        ),
      );

      DemoJobRequests.acceptJob(
        request.id,
      );

      _pendingJobs.removeWhere(
            (job) =>
        job.id ==
            request.id,
      );

      final activeJob =
      ActiveJob(
        id: request.id,
        requestId: request.id,
        orderNumber:
        request.orderNumber,
        workerId: 1,
        workerName:
        'Current Worker',
        customerId:
        request.id,
        customerName:
        request.customerName,
        customerPhone:
        request.customerPhone,
        isForAnotherPerson:
        request
            .isForAnotherPerson,
        recipientName:
        request.recipientName,
        recipientPhone:
        request.recipientPhone,
        recipientAddress:
        request
            .recipientAddress,
        recipientLatitude: 0,
        recipientLongitude: 0,
        serviceName:
        request.serviceName,
        serviceCategory:
        request
            .serviceCategory,
        serviceDescription:
        request.notes,
        servicePrice:
        request.servicePrice,
        acceptedAt:
        DateTime.now(),
        scheduledDate:
        request
            .scheduledDate,
        startedAt: null,
        arrivedAt: null,
        completedAt: null,
        status: 'Accepted',
        distanceKm:
        request.distanceKm,
        estimatedArrival:
        request
            .estimatedArrival,
        extraTimeTaken:
        Duration.zero,
        eligibleForBonus:
        true,
        bonusAmount: 100,
        bonusClaimed: false,
        notes: request.notes,
        isCompleted: false,
        rating: 0.0,
      );

      _activeJobs.add(
        activeJob,
      );

      notifyListeners();
    } catch (e) {
      _errorMessage =
      'Failed to accept job.';

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> rejectJob(
      int jobId,
      ) async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 300,
        ),
      );

      DemoJobRequests.rejectJob(
        jobId,
      );

      _pendingJobs.removeWhere(
            (job) =>
        job.id == jobId,
      );

      notifyListeners();
    } catch (e) {
      _errorMessage =
      'Failed to reject job.';

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // =========================
  // Active Job Actions
  // =========================

  Future<void> markOnTheWay(
      int jobId,
      ) async {
    await updateJobStatus(
      jobId: jobId,
      status: 'On The Way',
    );
  }

  Future<void> markArrived(
      int jobId,
      ) async {
    await _updateJob(
      jobId,
          (job) => job.copyWith(
        status: 'Arrived',
        arrivedAt:
        DateTime.now(),
      ),
    );
  }

  Future<void> startJob(
      int jobId,
      ) async {
    await _updateJob(
      jobId,
          (job) => job.copyWith(
        status:
        'In Progress',
        startedAt:
        DateTime.now(),
      ),
    );
  }

  Future<void> completeJob(
      int jobId,
      ) async {
    await _updateJob(
      jobId,
          (job) => job.copyWith(
        status: 'Completed',
        completedAt:
        DateTime.now(),
        isCompleted: true,
        bonusClaimed:
        job.hasBonus,
        rating:
        job.rating == 0
            ? 5.0
            : job.rating,
      ),
    );


  }

  Future<void> rejectActiveJob(
      int jobId,
      ) async {
    await _updateJob(
      jobId,
          (job) => job.copyWith(
        status: 'Rejected',
      ),
    );
  }

  Future<void> updateJobStatus({
    required int jobId,
    required String status,
  }) async {
    await _updateJob(
      jobId,
          (job) => job.copyWith(
        status: status,
      ),
    );
  }

  Future<void> _updateJob(
      int jobId,
      ActiveJob Function(
          ActiveJob,
          )
      updater,
      ) async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 300,
        ),
      );

      final index =
      _activeJobs.indexWhere(
            (job) =>
        job.id == jobId,
      );

      if (index == -1) {
        return;
      }

      _activeJobs[index] =
          updater(
            _activeJobs[index],
          );

      notifyListeners();
    } catch (e) {
      _errorMessage =
      'Failed to update job.';

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // =========================
  // Finders
  // =========================

  JobRequest? getPendingJob(
      int id,
      ) {
    try {
      return _pendingJobs
          .firstWhere(
            (job) => job.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  ActiveJob? getActiveJob(
      int id,
      ) {
    try {
      return _activeJobs
          .firstWhere(
            (job) => job.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  // =========================
  // Utilities
  // =========================

  void clearError() {
    _errorMessage = null;

    notifyListeners();
  }

  void clearJobs() {
    _pendingJobs.clear();

    _activeJobs.clear();

    notifyListeners();
  }

  void _setLoading(
      bool value,
      ) {
    _isLoading = value;

    notifyListeners();
  }
}