import 'package:flutter/material.dart';

import '../mock/demo_notifications.dart';
import '../models/worker_notification.dart';

class NotificationsProvider extends ChangeNotifier {
  List<WorkerNotification> _notifications = [];

  bool _isLoading = false;

  String? _errorMessage;

  // =========================
  // Getters
  // =========================

  List<WorkerNotification> get notifications =>
      List.unmodifiable(_notifications);

  bool get isLoading => _isLoading;

  String? get errorMessage => _errorMessage;

  int get totalCount =>
      _notifications.length;

  int get unreadCount =>
      _notifications
          .where(
            (notification) =>
        !notification.isRead,
      )
          .length;

  bool get hasUnread =>
      unreadCount > 0;

  /// Dashboard compatibility
  List<WorkerNotification> get latest =>
      _notifications.take(5).toList();

  // =========================
  // Initialization
  // =========================

  Future<void> initialize() async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 500,
        ),
      );

      _notifications = List.from(
        DemoNotifications.notifications,
      );

      _errorMessage = null;
    } catch (e) {
      _errorMessage =
      'Failed to load notifications.';
    } finally {
      _setLoading(false);
    }
  }

  /// Dashboard compatibility
  Future<void> fetchNotifications() async {
    await initialize();
  }

  Future<void> refresh() async {
    await initialize();
  }

  // =========================
  // Mark as Read
  // =========================

  void markAsRead(
      int notificationId,
      ) {
    final index =
    _notifications.indexWhere(
          (notification) =>
      notification.id ==
          notificationId,
    );

    if (index == -1) {
      return;
    }

    final notification =
    _notifications[index];

    if (notification.isRead) {
      return;
    }

    _notifications[index] =
        notification.copyWith(
          isRead: true,
        );

    notifyListeners();
  }

  // =========================
  // Mark All as Read
  // =========================

  void markAllAsRead() {
    _notifications =
        _notifications
            .map(
              (notification) =>
              notification.copyWith(
                isRead: true,
              ),
        )
            .toList();

    notifyListeners();
  }

  // =========================
  // Add Notification
  // =========================

  void addNotification(
      WorkerNotification notification,
      ) {
    _notifications.insert(
      0,
      notification,
    );

    notifyListeners();
  }

  // =========================
  // Remove Notification
  // =========================

  void removeNotification(
      int notificationId,
      ) {
    _notifications.removeWhere(
          (notification) =>
      notification.id ==
          notificationId,
    );

    notifyListeners();
  }

  // =========================
  // Find Notification
  // =========================

  WorkerNotification?
  getNotificationById(
      int id,
      ) {
    try {
      return _notifications
          .firstWhere(
            (notification) =>
        notification.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  // =========================
  // Utilities
  // =========================

  void clearNotifications() {
    _notifications.clear();

    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;

    notifyListeners();
  }

  void _setLoading(
      bool value,
      ) {
    _isLoading = value;

    notifyListeners();
  }
}