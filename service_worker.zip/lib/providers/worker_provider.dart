import 'package:flutter/material.dart';

import '../mock/demo_workers.dart';
import '../models/worker.dart';

class WorkerProvider extends ChangeNotifier {
  Worker? _currentWorker;

  bool _isLoading = false;

  String? _errorMessage;

  bool _isOnline = false;

  DateTime? _lastSeen;

  Worker? get currentWorker => _currentWorker;

  bool get isLoading => _isLoading;

  String? get errorMessage => _errorMessage;

  bool get hasWorker => _currentWorker != null;

  bool get isOnline => _isOnline;

  DateTime? get lastSeen => _lastSeen;

  String get workerStatus =>
      _isOnline ? 'Online' : 'Offline';

  Color get statusColor =>
      _isOnline ? Colors.green : Colors.red;

  IconData get statusIcon =>
      _isOnline
          ? Icons.check_circle
          : Icons.cancel;

  Future<void> loadWorker(
      int workerId,
      ) async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 500,
        ),
      );

      _currentWorker =
          DemoWorkers.getById(
            workerId,
          );

      _errorMessage = null;
    } catch (e) {
      _errorMessage =
      'Failed to load worker information.';
    } finally {
      _setLoading(false);
    }
  }

  void setOnlineStatus(
      bool value,
      ) {
    if (_isOnline == value) {
      return;
    }

    _isOnline = value;

    if (!_isOnline) {
      _lastSeen = DateTime.now();
    }

    notifyListeners();
  }

  void toggleOnlineStatus() {
    setOnlineStatus(
      !_isOnline,
    );
  }

  void updateWorker(
      Worker worker,
      ) {
    _currentWorker = worker;

    notifyListeners();
  }

  void updateProfileImage(
      String imagePath,
      ) {
    if (_currentWorker == null) {
      return;
    }

    _currentWorker =
        _currentWorker!.copyWith(
          profileImage: imagePath,
        );

    notifyListeners();
  }

  void updateLocation({
    required double latitude,
    required double longitude,
  }) {
    if (_currentWorker == null) {
      return;
    }

    _currentWorker =
        _currentWorker!.copyWith(
          latitude: latitude,
          longitude: longitude,
        );

    notifyListeners();
  }

  void updatePoints(
      int points,
      ) {
    if (_currentWorker == null) {
      return;
    }

    _currentWorker =
        _currentWorker!.copyWith(
          points: points,
        );

    notifyListeners();
  }

  void clearWorker() {
    _currentWorker = null;

    _isOnline = false;

    _lastSeen = null;

    notifyListeners();
  }

  void _setLoading(
      bool value,
      ) {
    _isLoading = value;

    notifyListeners();
  }
}