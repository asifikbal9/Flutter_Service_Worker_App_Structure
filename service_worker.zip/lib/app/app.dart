import 'package:flutter/material.dart';

import 'router.dart';
import 'theme.dart';

class ServiceWorkerApp extends StatelessWidget {
  const ServiceWorkerApp({
    super.key,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return MaterialApp(
      debugShowCheckedModeBanner:
      false,

      title:
      'Service Worker',

      theme:
      AppTheme.lightTheme,

      initialRoute:
      AppRouter.login,

      onGenerateRoute:
      AppRouter.generateRoute,

      builder: (
          context,
          child,
          ) {
        return GestureDetector(
          onTap: () {
            final currentFocus =
            FocusScope.of(
              context,
            );

            if (!currentFocus
                .hasPrimaryFocus) {
              currentFocus
                  .unfocus();
            }
          },

          child:
          child ??
              const SizedBox(),
        );
      },
    );
  }
}