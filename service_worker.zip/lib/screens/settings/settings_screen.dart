import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../providers/auth_provider.dart';
import '../../screens/auth/login_screen.dart';
import 'widgets/settings_tile.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({
    super.key,
  });

  @override
  State<SettingsScreen> createState() =>
      _SettingsScreenState();
}

class _SettingsScreenState
    extends State<SettingsScreen> {
  bool _notificationsEnabled = true;

  bool _darkModeEnabled = false;

  String _selectedLanguage =
      'English';

  final String _appVersion =
      '1.0.0';

  @override
  Widget build(
      BuildContext context) {
    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,

      appBar: AppBar(
        title: const Text(
          'Settings',
        ),
      ),

      body: ListView(
        padding:
        const EdgeInsets.all(
          20,
        ),

        children: [
          _buildSectionTitle(
            'Preferences',
          ),

          SettingsTile(
            icon:
            Icons.notifications,
            title:
            'Notifications',
            subtitle:
            'Receive job alerts and updates',

            trailing: Switch(
              value:
              _notificationsEnabled,

              activeColor:
              AppTheme
                  .primaryColor,

              onChanged: (
                  value,
                  ) {
                setState(() {
                  _notificationsEnabled =
                      value;
                });
              },
            ),
          ),

          SettingsTile(
            icon: Icons.dark_mode,
            title: 'Dark Mode',
            subtitle:
            'Enable dark theme',

            trailing: Switch(
              value:
              _darkModeEnabled,

              activeColor:
              AppTheme
                  .primaryColor,

              onChanged: (
                  value,
                  ) {
                setState(() {
                  _darkModeEnabled =
                      value;
                });

                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Theme switching can be implemented later.',
                    ),
                  ),
                );
              },
            ),
          ),

          SettingsTile(
            icon: Icons.language,
            title: 'Language',
            subtitle:
            _selectedLanguage,

            onTap:
            _showLanguageDialog,
          ),

          const SizedBox(
            height: 20,
          ),

          _buildSectionTitle(
            'Legal',
          ),

          SettingsTile(
            icon:
            Icons.privacy_tip,
            title:
            'Privacy Policy',
            subtitle:
            'View our privacy policy',

            onTap: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(
                const SnackBar(
                  content: Text(
                    'Privacy Policy screen can be added later.',
                  ),
                ),
              );
            },
          ),

          SettingsTile(
            icon:
            Icons.description,
            title:
            'Terms & Conditions',
            subtitle:
            'Read the terms of service',

            onTap: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(
                const SnackBar(
                  content: Text(
                    'Terms screen can be added later.',
                  ),
                ),
              );
            },
          ),

          const SizedBox(
            height: 20,
          ),

          _buildSectionTitle(
            'About',
          ),

          SettingsTile(
            icon:
            Icons.info_outline,
            title:
            'App Version',
            subtitle:
            'Version $_appVersion',

            trailing: const Icon(
              Icons.verified,
              color:
              AppTheme.successColor,
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          _buildSectionTitle(
            'Account',
          ),

          SettingsTile(
            icon: Icons.logout,
            title: 'Logout',
            subtitle:
            'Sign out from your account',

            iconColor:
            AppTheme.errorColor,

            isDestructive: true,

            onTap:
            _showLogoutDialog,
          ),

          const SizedBox(
            height: 40,
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(
      String title) {
    return Padding(
      padding:
      const EdgeInsets.only(
        bottom: 12,
        top: 8,
      ),

      child: Text(
        title,

        style:
        const TextStyle(
          fontSize: 18,

          fontWeight:
          FontWeight.bold,

          color:
          AppTheme.textPrimary,
        ),
      ),
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,

      builder: (
          context,
          ) {
        return AlertDialog(
          title: const Text(
            'Select Language',
          ),

          content: Column(
            mainAxisSize:
            MainAxisSize.min,

            children: [
              RadioListTile<String>(
                title: const Text(
                  'English',
                ),

                value: 'English',

                groupValue:
                _selectedLanguage,

                onChanged: (
                    value,
                    ) {
                  if (value ==
                      null) {
                    return;
                  }

                  setState(() {
                    _selectedLanguage =
                        value;
                  });

                  Navigator.pop(
                    context,
                  );
                },
              ),

              RadioListTile<String>(
                title: const Text(
                  'বাংলা',
                ),

                value: 'বাংলা',

                groupValue:
                _selectedLanguage,

                onChanged: (
                    value,
                    ) {
                  if (value ==
                      null) {
                    return;
                  }

                  setState(() {
                    _selectedLanguage =
                        value;
                  });

                  Navigator.pop(
                    context,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,

      builder: (
          context,
          ) {
        return AlertDialog(
          title: const Text(
            'Logout',
          ),

          content: const Text(
            'Are you sure you want to logout?',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  context,
                );
              },

              child: const Text(
                'Cancel',
              ),
            ),

            ElevatedButton(
              style:
              ElevatedButton.styleFrom(
                backgroundColor:
                AppTheme
                    .errorColor,

                foregroundColor:
                Colors.white,
              ),

              onPressed: () async {
                Navigator.pop(
                  context,
                );

                await context
                    .read<
                    AuthProvider>()
                    .logout();

                if (!mounted) {
                  return;
                }

                Navigator.pushAndRemoveUntil(
                  context,

                  MaterialPageRoute(
                    builder:
                        (_) =>
                    const LoginScreen(),
                  ),

                      (route) => false,
                );
              },

              child: const Text(
                'Logout',
              ),
            ),
          ],
        );
      },
    );
  }
}