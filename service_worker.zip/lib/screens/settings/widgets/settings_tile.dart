import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class SettingsTile extends StatelessWidget {
  final IconData icon;

  final String title;

  final String? subtitle;

  final Widget? trailing;

  final VoidCallback? onTap;

  final Color? iconColor;

  final bool isDestructive;

  const SettingsTile({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.iconColor,
    this.isDestructive = false,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    final Color tileColor =
    isDestructive
        ? AppTheme.errorColor
        : iconColor ??
        AppTheme.primaryColor;

    return Container(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius:
          BorderRadius.circular(
            AppTheme.radiusLG,
          ),
          child: Padding(
            padding:
            const EdgeInsets.all(
              18,
            ),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration:
                  BoxDecoration(
                    color: tileColor
                        .withOpacity(
                      0.10,
                    ),
                    borderRadius:
                    BorderRadius
                        .circular(
                      16,
                    ),
                  ),
                  child: Icon(
                    icon,
                    color: tileColor,
                    size: 26,
                  ),
                ),

                const SizedBox(
                  width: 16,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                    children: [
                      Text(
                        title,
                        style:
                        TextStyle(
                          fontSize:
                          16,
                          fontWeight:
                          FontWeight
                              .w600,
                          color:
                          isDestructive
                              ? AppTheme
                              .errorColor
                              : AppTheme
                              .textPrimary,
                        ),
                      ),

                      if (subtitle !=
                          null) ...[
                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          subtitle!,
                          style:
                          const TextStyle(
                            fontSize:
                            13,
                            color: AppTheme
                                .textSecondary,
                            height:
                            1.4,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                trailing ??
                    Icon(
                      Icons
                          .chevron_right,
                      color:
                      Colors.grey
                          .shade400,
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}