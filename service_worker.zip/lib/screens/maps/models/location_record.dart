class LocationRecord {
  /// Latitude in decimal degrees
  final double latitude;

  /// Longitude in decimal degrees
  final double longitude;

  /// GPS accuracy in meters
  final double accuracy;

  /// Speed in meters per second
  final double speed;

  /// Direction of travel in degrees (0–360)
  final double heading;

  /// Altitude in meters above sea level
  final double altitude;

  /// Timestamp when the location was measured
  final DateTime timestamp;

  const LocationRecord({
    required this.latitude,
    required this.longitude,
    required this.accuracy,
    required this.speed,
    required this.heading,
    required this.altitude,
    required this.timestamp,
  });

  /// Empty/default record
  factory LocationRecord.empty() {
    return LocationRecord(
      latitude: 0,
      longitude: 0,
      accuracy: 0,
      speed: 0,
      heading: 0,
      altitude: 0,
      timestamp: DateTime.now(),
    );
  }

  /// Create a copy with modified values
  LocationRecord copyWith({
    double? latitude,
    double? longitude,
    double? accuracy,
    double? speed,
    double? heading,
    double? altitude,
    DateTime? timestamp,
  }) {
    return LocationRecord(
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      accuracy: accuracy ?? this.accuracy,
      speed: speed ?? this.speed,
      heading: heading ?? this.heading,
      altitude: altitude ?? this.altitude,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  /// Convert to JSON (useful for APIs/Firebase)
  Map<String, dynamic> toJson() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'accuracy': accuracy,
      'speed': speed,
      'heading': heading,
      'altitude': altitude,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  /// Create object from JSON
  factory LocationRecord.fromJson(
      Map<String, dynamic> json,
      ) {
    return LocationRecord(
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      accuracy: (json['accuracy'] as num).toDouble(),
      speed: (json['speed'] as num).toDouble(),
      heading: (json['heading'] as num).toDouble(),
      altitude: (json['altitude'] as num).toDouble(),
      timestamp: DateTime.parse(
        json['timestamp'] as String,
      ),
    );
  }

  /// Speed in km/h
  double get speedInKmH => speed * 3.6;

  /// Check whether the location is valid
  bool get isValid =>
      latitude >= -90 &&
          latitude <= 90 &&
          longitude >= -180 &&
          longitude <= 180;

  @override
  String toString() {
    return 'LocationRecord('
        'latitude: $latitude, '
        'longitude: $longitude, '
        'accuracy: $accuracy, '
        'speed: $speed, '
        'heading: $heading, '
        'altitude: $altitude, '
        'timestamp: $timestamp'
        ')';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }

    return other is LocationRecord &&
        other.latitude == latitude &&
        other.longitude == longitude &&
        other.accuracy == accuracy &&
        other.speed == speed &&
        other.heading == heading &&
        other.altitude == altitude &&
        other.timestamp == timestamp;
  }

  @override
  int get hashCode {
    return Object.hash(
      latitude,
      longitude,
      accuracy,
      speed,
      heading,
      altitude,
      timestamp,
    );
  }
}