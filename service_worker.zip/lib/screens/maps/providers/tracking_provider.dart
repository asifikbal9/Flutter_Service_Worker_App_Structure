import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/location_record.dart';
import '../models/tracking_status.dart';
import '../services/tracking_service.dart';
import '../utils/permission_helper.dart';

class TrackingProvider extends ChangeNotifier {
  TrackingProvider({
    TrackingService? trackingService,
  }) : _trackingService =
      trackingService ?? TrackingService();

  final TrackingService _trackingService;

  String? _errorMessage;

  bool _autoFollow = true;

  // ---------------------------------------------------------------------------
  // Getters
  // ---------------------------------------------------------------------------

  TrackingStatus get status =>
      _trackingService.status;

  LocationRecord? get currentLocation =>
      _trackingService.currentLocation;

  List<LocationRecord> get history =>
      _trackingService.history;

  bool get isTracking =>
      _trackingService.isTracking;

  bool get hasLocation =>
      _trackingService.hasLocation;

  bool get autoFollow =>
      _autoFollow;

  String? get errorMessage =>
      _errorMessage;

  int get pointCount =>
      _trackingService.pointCount;

  DateTime? get sessionStartTime =>
      _trackingService.sessionStartTime;

  DateTime? get sessionEndTime =>
      _trackingService.sessionEndTime;

  // ---------------------------------------------------------------------------
  // Statistics
  // ---------------------------------------------------------------------------

  double get totalDistanceMeters =>
      _trackingService.totalDistanceMeters;

  double get totalDistanceKm =>
      _trackingService.totalDistanceKm;

  double get averageSpeedKmH =>
      _trackingService.averageSpeedKmH;

  double get maximumSpeedKmH =>
      _trackingService.maximumSpeedKmH;

  Duration get trackingDuration =>
      _trackingService.trackingDuration;

  bool get isMoving =>
      _trackingService.isMoving;

  String get movementType =>
      _trackingService.movementType;

  // ---------------------------------------------------------------------------
  // Tracking Controls
  // ---------------------------------------------------------------------------

  Future<bool> startTracking() async {
    _errorMessage = null;

    notifyListeners();

    try {
      final permissionResult =
      await PermissionHelper
          .validateLocationAccess();

      if (!permissionResult.isGranted) {
        _errorMessage =
            permissionResult.message;

        notifyListeners();

        return false;
      }

      await _trackingService.startTracking(
        onLocationUpdated: (_) {
          notifyListeners();
        },
        onStatusChanged: (_) {
          notifyListeners();
        },
        onError: (error) {
          _errorMessage =
              error.toString();

          notifyListeners();
        },
      );

      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage = e.toString();

      notifyListeners();

      return false;
    }
  }
  Future<bool> checkAndRequestLocation(BuildContext context) async {
    bool serviceEnabled =
    await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      final enableGps = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: const Text(
              'Location Required',
            ),
            content: const Text(
              'GPS is disabled. Please enable location services to continue.',
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(
                    context,
                    false,
                  );
                },
                child: const Text(
                  'Cancel',
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(
                    context,
                    true,
                  );
                },
                child: const Text(
                  'Enable GPS',
                ),
              ),
            ],
          );
        },
      );

      if (enableGps != true) {
        return false;
      }

      await Geolocator.openLocationSettings();

      await Future.delayed(
        const Duration(seconds: 2),
      );

      serviceEnabled =
      await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        return false;
      }
    }

    LocationPermission permission =
    await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission =
      await Geolocator.requestPermission();
    }

    if (permission ==
        LocationPermission.denied ||
        permission ==
            LocationPermission.deniedForever) {
      return false;
    }

    return true;
  }
  Future<void> stopTracking() async {
    await _trackingService.stopTracking(
      onStatusChanged: (_) {
        notifyListeners();
      },
    );

    notifyListeners();
  }

  Future<void> resetTracking() async {
    _errorMessage = null;

    await _trackingService.reset(
      onStatusChanged: (_) {
        notifyListeners();
      },
    );

    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Auto Follow
  // ---------------------------------------------------------------------------

  void setAutoFollow(bool enabled) {
    if (_autoFollow == enabled) {
      return;
    }

    _autoFollow = enabled;

    notifyListeners();
  }

  void toggleAutoFollow() {
    _autoFollow = !_autoFollow;

    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Permission Helpers
  // ---------------------------------------------------------------------------

  Future<void> openLocationSettings() async {
    await PermissionHelper
        .openLocationSettings();
  }

  Future<void> openAppSettings() async {
    await PermissionHelper
        .openAppSettings();
  }

  // ---------------------------------------------------------------------------
  // Route Information
  // ---------------------------------------------------------------------------

  LocationRecord? get firstLocation {
    if (history.isEmpty) {
      return null;
    }

    return history.first;
  }

  LocationRecord? get lastLocation {
    if (history.isEmpty) {
      return null;
    }

    return history.last;
  }

  bool get hasHistory =>
      history.isNotEmpty;

  // ---------------------------------------------------------------------------
  // UI Helpers
  // ---------------------------------------------------------------------------

  bool get isLoading =>
      status == TrackingStatus.locating;

  bool get hasError =>
      errorMessage != null;

  bool get canStartTracking =>
      status.canStart;

  bool get canStopTracking =>
      status.canStop;

  String get statusText =>
      status.label;

  // ---------------------------------------------------------------------------
  // Dispose
  // ---------------------------------------------------------------------------

  @override
  void dispose() {
    _trackingService.dispose();

    super.dispose();
  }
}