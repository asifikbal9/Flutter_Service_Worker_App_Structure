import 'package:url_launcher/url_launcher.dart';

class NavigationService {
  static Future<void> navigateToLocation({
    required double latitude,
    required double longitude,
  }) async {
    final Uri googleMapsUri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude&travelmode=driving',
    );

    if (await canLaunchUrl(googleMapsUri)) {
      await launchUrl(
        googleMapsUri,
        mode: LaunchMode.externalApplication,
      );
    }
  }
}