import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../core/constants/map_constants.dart';
import '../models/location_record.dart';

/// Professional route polyline widget.
///
/// Features:
/// • Draws traveled route
/// • Start marker support
/// • End marker support
/// • Handles empty routes safely
/// • Provides route statistics helpers
/// • Easily reusable across screens
class RoutePolyline extends StatelessWidget {
  final List<LocationRecord> locations;

  /// Whether the route should be visible.
  final bool visible;

  /// Polyline color.
  final Color? color;

  /// Stroke width.
  final double? strokeWidth;

  /// Whether to show the starting point marker.
  final bool showStartMarker;

  /// Whether to show the ending point marker.
  final bool showEndMarker;

  const RoutePolyline({
    super.key,
    required this.locations,
    this.visible = true,
    this.color,
    this.strokeWidth,
    this.showStartMarker = true,
    this.showEndMarker = true,
  });

  @override
  Widget build(BuildContext context) {
    if (!visible || locations.length < 2) {
      return const SizedBox.shrink();
    }

    return Stack(
      children: [
        FlutterMap(
          children: [
            PolylineLayer(
              polylines: [
                Polyline(
                  points: routePoints,
                  color:
                  color ??
                      MapConstants.routeColor,
                  strokeWidth:
                  strokeWidth ??
                      MapConstants
                          .routeStrokeWidth,
                ),
              ],
            ),

            MarkerLayer(
              markers: [
                if (showStartMarker)
                  Marker(
                    point: routePoints.first,
                    width: 40,
                    height: 40,
                    child:
                    const _StartMarker(),
                  ),

                if (showEndMarker)
                  Marker(
                    point: routePoints.last,
                    width: 40,
                    height: 40,
                    child:
                    const _EndMarker(),
                  ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  /// Converts history into map points.
  List<LatLng> get routePoints {
    return locations
        .map(
          (location) => LatLng(
        location.latitude,
        location.longitude,
      ),
    )
        .toList();
  }

  /// Total number of route points.
  int get pointCount =>
      locations.length;

  /// Starting location.
  LocationRecord? get startLocation {
    if (locations.isEmpty) {
      return null;
    }

    return locations.first;
  }

  /// Ending location.
  LocationRecord? get endLocation {
    if (locations.isEmpty) {
      return null;
    }

    return locations.last;
  }

  /// Whether there is enough data to render a route.
  bool get hasRoute =>
      locations.length >= 2;
}

class _StartMarker
    extends StatelessWidget {
  const _StartMarker();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.green,
        border: Border.all(
          color: Colors.white,
          width: 3,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(
              0x33000000,
            ),
            blurRadius: 6,
            offset: Offset(
              0,
              2,
            ),
          ),
        ],
      ),
      child: const Center(
        child: Icon(
          Icons.play_arrow,
          color: Colors.white,
          size: 18,
        ),
      ),
    );
  }
}

class _EndMarker
    extends StatelessWidget {
  const _EndMarker();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.red,
        border: Border.all(
          color: Colors.white,
          width: 3,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(
              0x33000000,
            ),
            blurRadius: 6,
            offset: Offset(
              0,
              2,
            ),
          ),
        ],
      ),
      child: const Center(
        child: Icon(
          Icons.flag,
          color: Colors.white,
          size: 18,
        ),
      ),
    );
  }
}