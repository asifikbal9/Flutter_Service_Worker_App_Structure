import 'package:flutter/material.dart';

import '../core/constants/map_constants.dart';
import '../models/location_record.dart';
import '../utils/time_formatter.dart';

class LocationInfoCard extends StatelessWidget {
  final LocationRecord? location;

  final double totalDistanceKm;

  final double averageSpeedKmH;

  final double maximumSpeedKmH;

  final Duration trackingDuration;

  final String movementType;

  final bool isTracking;

  const LocationInfoCard({
    super.key,
    required this.location,
    required this.totalDistanceKm,
    required this.averageSpeedKmH,
    required this.maximumSpeedKmH,
    required this.trackingDuration,
    required this.movementType,
    required this.isTracking,
  });

  @override
  Widget build(BuildContext context) {
    if (location == null) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);

    return SafeArea(
      top: false,
      child: Padding(
        padding: MapConstants.overlayPadding,
        child: Card(
          elevation: MapConstants.cardElevation,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              MapConstants.cardBorderRadius,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Row(
                  children: [
                    Icon(
                      isTracking
                          ? Icons.gps_fixed
                          : Icons.gps_off,
                      color: isTracking
                          ? MapConstants.trackingColor
                          : MapConstants.idleColor,
                    ),

                    const SizedBox(width: 8),

                    Expanded(
                      child: Text(
                        isTracking
                            ? 'Live Tracking'
                            : 'Tracking Stopped',
                        style: theme.textTheme.titleMedium
                            ?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                    Container(
                      padding:
                      const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: _movementColor(
                          movementType,
                        ).withOpacity(0.15),
                        borderRadius:
                        BorderRadius.circular(20),
                      ),
                      child: Text(
                        movementType,
                        style: TextStyle(
                          color: _movementColor(
                            movementType,
                          ),
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // Coordinates
                _InfoRow(
                  icon: Icons.location_on,
                  title: 'Latitude',
                  value:
                  location!.latitude.toStringAsFixed(
                    6,
                  ),
                ),

                const SizedBox(height: 8),

                _InfoRow(
                  icon: Icons.location_on_outlined,
                  title: 'Longitude',
                  value:
                  location!.longitude.toStringAsFixed(
                    6,
                  ),
                ),

                const Divider(height: 24),

                // Speed / Accuracy
                Row(
                  children: [
                    Expanded(
                      child: _MetricTile(
                        icon: Icons.speed,
                        label: 'Speed',
                        value:
                        '${location!.speedInKmH.toStringAsFixed(1)} km/h',
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: _MetricTile(
                        icon: Icons.gps_fixed,
                        label: 'Accuracy',
                        value:
                        '±${location!.accuracy.toStringAsFixed(1)} m',
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: _MetricTile(
                        icon: Icons.straighten,
                        label: 'Distance',
                        value:
                        '${totalDistanceKm.toStringAsFixed(2)} km',
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: _MetricTile(
                        icon: Icons.navigation,
                        label: 'Heading',
                        value:
                        '${location!.heading.toStringAsFixed(0)}°',
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: _MetricTile(
                        icon: Icons.trending_up,
                        label: 'Avg Speed',
                        value:
                        '${averageSpeedKmH.toStringAsFixed(1)} km/h',
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: _MetricTile(
                        icon: Icons.flash_on,
                        label: 'Max Speed',
                        value:
                        '${maximumSpeedKmH.toStringAsFixed(1)} km/h',
                      ),
                    ),
                  ],
                ),

                const Divider(height: 24),

                // Time Information
                _InfoRow(
                  icon: Icons.access_time,
                  title: 'Last Updated',
                  value:
                  TimeFormatter.smartFormat(
                    location!.timestamp,
                  ),
                ),

                const SizedBox(height: 8),

                _InfoRow(
                  icon: Icons.timer,
                  title: 'Tracking Duration',
                  value:
                  TimeFormatter.formatDuration(
                    trackingDuration,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _movementColor(String movement) {
    switch (movement.toLowerCase()) {
      case 'walking':
        return Colors.green;

      case 'cycling':
        return Colors.orange;

      case 'driving':
        return Colors.blue;

      case 'fast travel':
        return Colors.red;

      default:
        return Colors.grey;
    }
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;

  final String title;

  final String value;

  const _InfoRow({
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: Colors.grey.shade700,
        ),

        const SizedBox(width: 10),

        Expanded(
          child: Text(
            title,
            style:
            Theme.of(context).textTheme.bodyMedium,
          ),
        ),

        Text(
          value,
          style:
          Theme.of(context).textTheme.bodyMedium
              ?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _MetricTile extends StatelessWidget {
  final IconData icon;

  final String label;

  final String value;

  const _MetricTile({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context)
            .colorScheme
            .surfaceContainerHighest
            .withOpacity(0.5),
        borderRadius:
        BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(icon),

          const SizedBox(height: 8),

          Text(
            value,
            textAlign: TextAlign.center,
            style:
            Theme.of(context).textTheme.titleSmall
                ?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            label,
            textAlign: TextAlign.center,
            style:
            Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}