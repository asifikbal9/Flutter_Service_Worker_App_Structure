import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../models/active_job.dart';
import '../../providers/jobs_provider.dart';
import 'job_details_screen.dart';
import 'widgets/completed_job_card.dart';

class CompletedJobsScreen extends StatelessWidget {
  const CompletedJobsScreen({
    super.key,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Consumer<JobsProvider>(
      builder: (
          context,
          jobsProvider,
          child,
          ) {
        final completedJobs =
        jobsProvider.activeJobs
            .where(
              (job) =>
          job.isCompletedStatus,
        )
            .toList();

        return Scaffold(
          backgroundColor:
          AppTheme.scaffoldColor,

          appBar: AppBar(
            title: const Text(
              'Completed Jobs',
            ),
            elevation: 0,
          ),

          body: completedJobs.isEmpty
              ? _buildEmptyState(
            context,
          )
              : Column(
            children: [
              _buildSummary(
                completedJobs,
              ),

              Expanded(
                child:
                RefreshIndicator(
                  onRefresh:
                  jobsProvider
                      .refreshJobs,

                  child:
                  ListView.builder(
                    physics:
                    const BouncingScrollPhysics(),

                    padding:
                    const EdgeInsets.all(
                      20,
                    ),

                    itemCount:
                    completedJobs
                        .length,

                    itemBuilder: (
                        context,
                        index,
                        ) {
                      final job =
                      completedJobs[
                      index];

                      return CompletedJobCard(
                        job: job,

                        onViewDetails:
                            () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (
                                  _,
                                  ) =>
                                  JobDetailsScreen(
                                    jobId:
                                    job.id,
                                  ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSummary(
      List<ActiveJob> jobs,
      ) {
    final totalEarnings =
    jobs.fold<double>(
      0,
          (
          total,
          job,
          ) =>
      total +
          job.totalEarnings,
    );

    final totalBonus =
    jobs.fold<double>(
      0,
          (
          total,
          job,
          ) =>
      total +
          job.bonusAmount,
    );

    return Container(
      margin:
      const EdgeInsets.all(
        20,
      ),

      padding:
      const EdgeInsets.all(
        20,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          24,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 16,

            offset:
            const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Row(
        children: [
          Expanded(
            child: _summaryItem(
              title:
              'Completed',

              value:
              '${jobs.length}',

              color:
              Colors.green,

              icon:
              Icons.check_circle,
            ),
          ),

          Expanded(
            child: _summaryItem(
              title:
              'Bonus',

              value:
              '৳${totalBonus.toStringAsFixed(0)}',

              color:
              Colors.orange,

              icon:
              Icons.workspace_premium,
            ),
          ),

          Expanded(
            child: _summaryItem(
              title:
              'Earned',

              value:
              '৳${totalEarnings.toStringAsFixed(0)}',

              color:
              Colors.blue,

              icon:
              Icons.payments,
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryItem({
    required String title,
    required String value,
    required Color color,
    required IconData icon,
  }) {
    return Column(
      children: [
        Container(
          width: 52,

          height: 52,

          decoration:
          BoxDecoration(
            color:
            color.withOpacity(
              0.10,
            ),

            shape:
            BoxShape.circle,
          ),

          child: Icon(
            icon,

            color: color,
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        Text(
          value,

          style:
          const TextStyle(
            fontSize: 18,

            fontWeight:
            FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 4,
        ),

        Text(
          title,

          style:
          const TextStyle(
            color: AppTheme
                .textSecondary,

            fontSize: 12,
          ),

          textAlign:
          TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildEmptyState(
      BuildContext context,
      ) {
    return RefreshIndicator(
      onRefresh: () async {
        await context
            .read<JobsProvider>()
            .refreshJobs();
      },

      child: ListView(
        physics:
        const AlwaysScrollableScrollPhysics(),

        children: [
          SizedBox(
            height:
            MediaQuery.of(
              context,
            ).size.height *
                0.18,
          ),

          const Icon(
            Icons.history,

            size: 90,

            color: Colors.grey,
          ),

          const SizedBox(
            height: 24,
          ),

          const Center(
            child: Text(
              'No Completed Jobs',

              style: TextStyle(
                fontSize: 24,

                fontWeight:
                FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(
            height: 12,
          ),

          const Padding(
            padding:
            EdgeInsets.symmetric(
              horizontal: 40,
            ),

            child: Text(
              'Completed services will appear here.',

              textAlign:
              TextAlign.center,

              style: TextStyle(
                color: AppTheme
                    .textSecondary,

                fontSize: 16,
              ),
            ),
          ),

          const SizedBox(
            height: 30,
          ),

          Center(
            child:
            ElevatedButton.icon(
              onPressed: () {
                context
                    .read<
                    JobsProvider>()
                    .refreshJobs();
              },

              icon: const Icon(
                Icons.refresh,
              ),

              label: const Text(
                'Refresh',
              ),
            ),
          ),
        ],
      ),
    );
  }
}