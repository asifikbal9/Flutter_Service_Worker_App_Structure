import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../models/job_request.dart';

class PendingJobCard extends StatelessWidget {
  final JobRequest job;

  final VoidCallback? onAccept;

  final VoidCallback? onReject;

  final VoidCallback? onViewDetails;

  const PendingJobCard({
    super.key,
    required this.job,
    this.onAccept,
    this.onReject,
    this.onViewDetails,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 500,
      ),

      tween: Tween(
        begin: 0,
        end: 1,
      ),

      curve: Curves.easeOutCubic,

      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            20 * (1 - value),
          ),

          child: Opacity(
            opacity: value,

            child: child,
          ),
        );
      },

      child: Container(
        margin: const EdgeInsets.only(
          bottom: 20,
        ),

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius:
          BorderRadius.circular(
            24,
          ),

          boxShadow: [
            BoxShadow(
              color: Colors.black
                  .withOpacity(
                0.05,
              ),

              blurRadius: 16,

              offset: const Offset(
                0,
                8,
              ),
            ),
          ],
        ),

        child: Padding(
          padding:
          const EdgeInsets.all(
            20,
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        Text(
                          job.serviceName,

                          style:
                          const TextStyle(
                            fontSize: 20,

                            fontWeight:
                            FontWeight
                                .bold,
                          ),
                        ),

                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          job.orderNumber,

                          style:
                          const TextStyle(
                            color: AppTheme
                                .textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),

                  if (job.hasBonus)
                    Container(
                      padding:
                      const EdgeInsets
                          .symmetric(
                        horizontal:
                        12,

                        vertical: 8,
                      ),

                      decoration:
                      BoxDecoration(
                        color: Colors
                            .amber
                            .shade100,

                        borderRadius:
                        BorderRadius
                            .circular(
                          12,
                        ),
                      ),

                      child: Text(
                        'Bonus ৳${job.bonusAmount.toStringAsFixed(0)}',

                        style:
                        const TextStyle(
                          fontWeight:
                          FontWeight
                              .bold,
                        ),
                      ),
                    ),
                ],
              ),

              const Divider(
                height: 28,
              ),

              _buildSection(
                'Service Booked By',
                [
                  _infoRow(
                    Icons.person,
                    job.customerName,
                  ),

                  _infoRow(
                    Icons.phone,
                    job.customerPhone,
                  ),
                ],
              ),

              const SizedBox(
                height: 20,
              ),

              _buildSection(
                'Customer To Serve',
                [
                  _infoRow(
                    Icons.person_outline,
                    job.recipientName,
                  ),

                  _infoRow(
                    Icons.phone,
                    job.recipientPhone,
                  ),

                  _infoRow(
                    Icons.location_on,
                    job.recipientAddress,
                  ),
                ],
              ),

              const SizedBox(
                height: 20,
              ),

              Container(
                padding:
                const EdgeInsets
                    .all(
                  16,
                ),

                decoration:
                BoxDecoration(
                  color:
                  Colors.grey
                      .shade50,

                  borderRadius:
                  BorderRadius
                      .circular(
                    18,
                  ),
                ),

                child: Column(
                  children: [
                    _detailRow(
                      'Scheduled',

                      DateFormat(
                        'dd MMM • hh:mm a',
                      ).format(
                        job.scheduledDate,
                      ),
                    ),

                    _detailRow(
                      'Distance',

                      '${job.distanceKm.toStringAsFixed(1)} km',
                    ),

                    _detailRow(
                      'ETA',

                      '${job.estimatedArrival.inMinutes} min',
                    ),

                    _detailRow(
                      'Service Fee',

                      '৳${job.servicePrice.toStringAsFixed(0)}',
                    ),
                  ],
                ),
              ),

              if (job.notes
                  .trim()
                  .isNotEmpty)
                ...[
                  const SizedBox(
                    height: 20,
                  ),

                  Container(
                    padding:
                    const EdgeInsets
                        .all(
                      16,
                    ),

                    decoration:
                    BoxDecoration(
                      color: Colors
                          .blue
                          .shade50,

                      borderRadius:
                      BorderRadius
                          .circular(
                        18,
                      ),
                    ),

                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        const Icon(
                          Icons.notes,
                        ),

                        const SizedBox(
                          width: 12,
                        ),

                        Expanded(
                          child: Text(
                            job.notes,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  Expanded(
                    child:
                    OutlinedButton(
                      onPressed:
                      onReject,

                      style:
                      OutlinedButton
                          .styleFrom(
                        foregroundColor:
                        Colors.red,
                      ),

                      child: const Text(
                        'Reject',
                      ),
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child:
                    ElevatedButton(
                      onPressed:
                      onViewDetails,

                      child: const Text(
                        'Details',
                      ),
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child:
                    ElevatedButton(
                      onPressed:
                      onAccept,

                      style:
                      ElevatedButton
                          .styleFrom(
                        backgroundColor:
                        AppTheme
                            .primaryColor,
                      ),

                      child: const Text(
                        'Accept',
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(
      String title,
      List<Widget> children,
      ) {
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment
          .start,

      children: [
        Text(
          title,

          style: const TextStyle(
            fontSize: 16,

            fontWeight:
            FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 10,
        ),

        ...children,
      ],
    );
  }

  Widget _infoRow(
      IconData icon,
      String text,
      ) {
    return Padding(
      padding:
      const EdgeInsets.only(
        bottom: 8,
      ),

      child: Row(
        children: [
          Icon(
            icon,

            size: 18,

            color: AppTheme
                .primaryColor,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              text,
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(
      String title,
      String value,
      ) {
    return Padding(
      padding:
      const EdgeInsets.only(
        bottom: 10,
      ),

      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
            ),
          ),

          Text(
            value,

            style:
            const TextStyle(
              fontWeight:
              FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}