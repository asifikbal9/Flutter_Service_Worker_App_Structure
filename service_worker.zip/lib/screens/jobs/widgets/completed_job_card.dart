import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';

class CompletedJobCard extends StatelessWidget {
  final ActiveJob job;

  final VoidCallback? onViewDetails;

  const CompletedJobCard({
    super.key,
    required this.job,
    this.onViewDetails,
  });

  @override
  Widget build(BuildContext context) {
    final completedDate =
        job.completedAt ?? DateTime.now();

    return Container(
      margin: const EdgeInsets.only(
        bottom: 16,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(
          20,
        ),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration:
                  BoxDecoration(
                    color: Colors.green
                        .withOpacity(
                      0.10,
                    ),
                    borderRadius:
                    BorderRadius
                        .circular(
                      16,
                    ),
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color:
                    Colors.green,
                    size: 30,
                  ),
                ),

                const SizedBox(
                  width: 14,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                    children: [
                      Text(
                        job.serviceName,
                        style:
                        const TextStyle(
                          fontSize:
                          18,
                          fontWeight:
                          FontWeight
                              .bold,
                          color: AppTheme
                              .textPrimary,
                        ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        job.orderNumber,
                        style:
                        const TextStyle(
                          color: AppTheme
                              .textSecondary,
                          fontSize:
                          13,
                        ),
                      ),
                    ],
                  ),
                ),

                Container(
                  padding:
                  const EdgeInsets
                      .symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration:
                  BoxDecoration(
                    color: Colors.green
                        .withOpacity(
                      0.10,
                    ),
                    borderRadius:
                    BorderRadius
                        .circular(
                      20,
                    ),
                  ),
                  child: const Text(
                    'Completed',
                    style: TextStyle(
                      color:
                      Colors.green,
                      fontWeight:
                      FontWeight
                          .bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 20,
            ),

            _buildInfoRow(
              Icons.person_outline,
              'Customer',
              job.customerName,
            ),

            const SizedBox(
              height: 12,
            ),

            _buildInfoRow(
              Icons.calendar_today,
              'Completed On',
              '${completedDate.day}/${completedDate.month}/${completedDate.year}',
            ),

            const SizedBox(
              height: 20,
            ),

            Row(
              children: [
                Expanded(
                  child:
                  _earningCard(
                    title:
                    'Service Fee',
                    value:
                    '৳${job.servicePrice.toStringAsFixed(0)}',
                    icon:
                    Icons.payments,
                    color:
                    Colors.blue,
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child:
                  _earningCard(
                    title:
                    'Bonus',
                    value:
                    '৳${job.bonusAmount.toStringAsFixed(0)}',
                    icon:
                    Icons
                        .workspace_premium,
                    color:
                    Colors.orange,
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 16,
            ),

            Container(
              padding:
              const EdgeInsets.all(
                14,
              ),
              decoration:
              BoxDecoration(
                color: AppTheme
                    .primaryColor
                    .withOpacity(
                  0.08,
                ),
                borderRadius:
                BorderRadius.circular(
                  14,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons
                        .account_balance_wallet,
                    color: AppTheme
                        .primaryColor,
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                      children: [
                        const Text(
                          'Total Earnings',
                          style:
                          TextStyle(
                            color: AppTheme
                                .textSecondary,
                            fontSize:
                            13,
                          ),
                        ),

                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          '৳${job.totalEarnings.toStringAsFixed(0)}',
                          style:
                          const TextStyle(
                            fontSize:
                            22,
                            fontWeight:
                            FontWeight
                                .bold,
                            color: AppTheme
                                .textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 16,
            ),

            Row(
              children: [
                const Icon(
                  Icons.star,
                  color:
                  Colors.amber,
                  size: 20,
                ),

                const SizedBox(
                  width: 6,
                ),

                Text(
                  job.rating
                      .toStringAsFixed(
                    1,
                  ),
                  style:
                  const TextStyle(
                    fontWeight:
                    FontWeight
                        .w600,
                  ),
                ),

                const Spacer(),

                TextButton.icon(
                  onPressed:
                  onViewDetails,

                  icon: const Icon(
                    Icons
                        .visibility_outlined,
                  ),

                  label: const Text(
                    'View Details',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(
      IconData icon,
      String title,
      String value,
      ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color:
          AppTheme.textSecondary,
        ),

        const SizedBox(
          width: 12,
        ),

        Text(
          '$title:',
          style: const TextStyle(
            color: AppTheme
                .textSecondary,
            fontWeight:
            FontWeight.w500,
          ),
        ),

        const SizedBox(
          width: 8,
        ),

        Expanded(
          child: Text(
            value,
            style:
            const TextStyle(
              fontWeight:
              FontWeight.w600,
              color: AppTheme
                  .textPrimary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _earningCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding:
      const EdgeInsets.all(
        14,
      ),
      decoration: BoxDecoration(
        color:
        color.withOpacity(
          0.08,
        ),
        borderRadius:
        BorderRadius.circular(
          14,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
          ),

          const SizedBox(
            height: 10,
          ),

          Text(
            title,
            style:
            const TextStyle(
              color: AppTheme
                  .textSecondary,
              fontSize: 12,
            ),
            textAlign:
            TextAlign.center,
          ),

          const SizedBox(
            height: 6,
          ),

          Text(
            value,
            style:
            const TextStyle(
              fontWeight:
              FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}