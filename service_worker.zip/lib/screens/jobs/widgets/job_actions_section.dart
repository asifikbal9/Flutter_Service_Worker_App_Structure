import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';
import '../../../widgets/buttons/gradient_button.dart';

class JobActionsSection extends StatelessWidget {
  final ActiveJob job;

  final VoidCallback? onStartJob;
  final VoidCallback? onMarkArrived;
  final VoidCallback? onCompleteJob;

  const JobActionsSection({
    super.key,
    required this.job,
    this.onStartJob,
    this.onMarkArrived,
    this.onCompleteJob,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          const Text(
            'Job Actions',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            _statusMessage(),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              height: 1.4,
            ),
          ),

          const SizedBox(height: 24),

          if (job.isCompletedStatus)
            _buildCompletedView(),

          // Accepted → Start Journey
          if (job.isAccepted)
            GradientButton(
              text: 'Start Journey',
              icon: Icons.directions_car,
              onPressed: onStartJob,
            ),

          // On The Way → Arrived / Start Service
          if (job.isOnTheWay)
            Column(
              children: [
                GradientButton(
                  text: 'Mark as Arrived',
                  icon: Icons.location_on,
                  onPressed: onMarkArrived,
                ),

                const SizedBox(height: 12),

                OutlinedButton.icon(
                  onPressed: onStartJob,
                  icon: const Icon(
                    Icons.play_arrow,
                  ),
                  label: const Text(
                    'Start Service',
                  ),
                  style:
                  OutlinedButton.styleFrom(
                    minimumSize:
                    const Size(
                      double.infinity,
                      52,
                    ),
                    foregroundColor:
                    AppTheme
                        .primaryColor,
                    side: const BorderSide(
                      color: AppTheme
                          .primaryColor,
                    ),
                    shape:
                    RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(
                        14,
                      ),
                    ),
                  ),
                ),
              ],
            ),

          // Arrived → Start Service
          if (job.isArrived)
            GradientButton(
              text: 'Start Service',
              icon: Icons.play_arrow,
              onPressed: onStartJob,
            ),

          // In Progress → Complete
          if (job.isInProgress)
            GradientButton(
              text: 'Complete Job',
              icon: Icons.check_circle,
              onPressed: onCompleteJob,
            ),
        ],
      ),
    );
  }

  Widget _buildCompletedView() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(
        bottom: 16,
      ),
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(
          0.08,
        ),
        borderRadius:
        BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.check_circle,
            color: Colors.green,
            size: 52,
          ),

          const SizedBox(height: 12),

          const Text(
            'Job Completed',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            job.completedAt != null
                ? 'Completed successfully.'
                : 'This job has been completed.',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  String _statusMessage() {
    if (job.isAccepted) {
      return 'Start your journey to the customer location.';
    }

    if (job.isOnTheWay) {
      return 'You are heading towards the service location.';
    }

    if (job.isArrived) {
      return 'You have arrived. Start the service when ready.';
    }

    if (job.isInProgress) {
      return 'Complete the service once all work is finished.';
    }

    if (job.isCompletedStatus) {
      return 'This job has already been completed.';
    }

    return 'Manage the current job status.';
  }
}