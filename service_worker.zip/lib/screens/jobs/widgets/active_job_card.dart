import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../screens/maps/screens/tracking_screen.dart';
import '../../../models/active_job.dart';

class ActiveJobCard extends StatelessWidget {
  final ActiveJob job;

  final VoidCallback? onStatusChanged;

  const ActiveJobCard({
    super.key,
    required this.job,
    this.onStatusChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 500,
      ),

      tween: Tween(
        begin: 0,
        end: 1,
      ),

      curve: Curves.easeOutCubic,

      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            20 * (1 - value),
          ),

          child: Opacity(
            opacity: value,

            child: child,
          ),
        );
      },

      child: Container(
        margin:
        const EdgeInsets.only(
          bottom: 20,
        ),

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius:
          BorderRadius.circular(
            24,
          ),

          boxShadow: [
            BoxShadow(
              color: Colors.black
                  .withOpacity(
                0.05,
              ),

              blurRadius: 16,

              offset:
              const Offset(
                0,
                8,
              ),
            ),
          ],
        ),

        child: Padding(
          padding:
          const EdgeInsets.all(
            20,
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              _buildHeader(),

              const Divider(
                height: 28,
              ),

              _buildCustomerSection(),

              const SizedBox(
                height: 20,
              ),

              _buildRecipientSection(),

              const SizedBox(
                height: 20,
              ),

              _buildTravelSection(),

              const SizedBox(
                height: 20,
              ),

              _buildBonusSection(),

              if (job.notes
                  .trim()
                  .isNotEmpty)
                ...[
                  const SizedBox(
                    height: 20,
                  ),

                  _buildNotesSection(),
                ],

              const SizedBox(
                height: 24,
              ),

              _buildActionButtons(
                context,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              Text(
                job.serviceName,

                style:
                const TextStyle(
                  fontSize: 22,

                  fontWeight:
                  FontWeight
                      .bold,
                ),
              ),

              const SizedBox(
                height: 6,
              ),

              Text(
                job.orderNumber,

                style:
                const TextStyle(
                  color: AppTheme
                      .textSecondary,
                ),
              ),
            ],
          ),
        ),

        _buildStatusChip(),
      ],
    );
  }

  Widget _buildStatusChip() {
    Color color;

    switch (job.status
        .toLowerCase()) {
      case 'accepted':
        color = Colors.blue;
        break;

      case 'on the way':
        color = Colors.orange;
        break;

      case 'arrived':
        color = Colors.purple;
        break;

      case 'in progress':
        color = Colors.teal;
        break;

      case 'completed':
        color = Colors.green;
        break;

      default:
        color = Colors.grey;
    }

    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 8,
      ),

      decoration: BoxDecoration(
        color:
        color.withOpacity(
          0.12,
        ),

        borderRadius:
        BorderRadius.circular(
          14,
        ),
      ),

      child: Text(
        job.status,

        style: TextStyle(
          color: color,

          fontWeight:
          FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildCustomerSection() {
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,

      children: [
        const Text(
          'Service Booked By',

          style: TextStyle(
            fontWeight:
            FontWeight.bold,

            fontSize: 16,
          ),
        ),

        const SizedBox(
          height: 10,
        ),

        _infoRow(
          Icons.person,
          job.customerName,
        ),

        _infoRow(
          Icons.phone,
          job.customerPhone,
        ),
      ],
    );
  }

  Widget _buildRecipientSection() {
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,

      children: [
        const Text(
          'Customer To Serve',

          style: TextStyle(
            fontWeight:
            FontWeight.bold,

            fontSize: 16,
          ),
        ),

        const SizedBox(
          height: 10,
        ),

        _infoRow(
          Icons.person_outline,
          job.recipientName,
        ),

        _infoRow(
          Icons.phone,
          job.recipientPhone,
        ),

        _infoRow(
          Icons.location_on,
          job.recipientAddress,
        ),
      ],
    );
  }

  Widget _buildTravelSection() {
    return Container(
      padding:
      const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color:
        Colors.grey.shade50,

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Column(
        children: [
          _travelRow(
            'Distance',
            '${job.distanceKm.toStringAsFixed(1)} km',
          ),

          _travelRow(
            'ETA',
            '${job.estimatedArrival.inMinutes} min',
          ),

          _travelRow(
            'Extra Time',
            '${job.extraTimeTaken.inMinutes} min',
          ),

          _travelRow(
            'Scheduled',
            DateFormat(
              'dd MMM • hh:mm a',
            ).format(
              job.scheduledDate,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBonusSection() {
    return Container(
      padding:
      const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color:
        Colors.amber.shade50,

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Row(
        children: [
          const Icon(
            Icons.workspace_premium,

            color: Colors.amber,
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,

              children: [
                Text(
                  job.hasBonus
                      ? 'Bonus Available'
                      : 'No Bonus',

                  style:
                  const TextStyle(
                    fontWeight:
                    FontWeight
                        .bold,
                  ),
                ),

                if (job.hasBonus)
                  Text(
                    '৳${job.bonusAmount.toStringAsFixed(0)}',
                  ),
              ],
            ),
          ),

          Text(
            '৳${job.totalEarnings.toStringAsFixed(0)}',

            style:
            const TextStyle(
              fontSize: 18,

              fontWeight:
              FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotesSection() {
    return Container(
      padding:
      const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color:
        Colors.blue.shade50,

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Row(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          const Icon(
            Icons.notes,
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Text(
              job.notes,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(
      BuildContext context,
      ) {
    return Wrap(
      spacing: 12,

      runSpacing: 12,

      children: [
        OutlinedButton.icon(
          onPressed: () {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(
              SnackBar(
                content: Text(
                  'Calling ${job.customerPhone}',
                ),
              ),
            );
          },

          icon: const Icon(
            Icons.call,
          ),

          label: const Text(
            'Customer',
          ),
        ),

        OutlinedButton.icon(
          onPressed: () {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(
              SnackBar(
                content: Text(
                  'Calling ${job.recipientPhone}',
                ),
              ),
            );
          },

          icon: const Icon(
            Icons.phone,
          ),

          label: const Text(
            'Recipient',
          ),
        ),

        ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                const TrackingScreen(),
              ),
            );
          },

          icon: const Icon(
            Icons.map,
          ),

          label: const Text(
            'Map',
          ),
        ),
      ],
    );
  }

  Widget _infoRow(
      IconData icon,
      String text,
      ) {
    return Padding(
      padding:
      const EdgeInsets.only(
        bottom: 8,
      ),

      child: Row(
        crossAxisAlignment:
        CrossAxisAlignment
            .start,

        children: [
          Icon(
            icon,

            size: 18,

            color: AppTheme
                .primaryColor,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              text,
            ),
          ),
        ],
      ),
    );
  }

  Widget _travelRow(
      String title,
      String value,
      ) {
    return Padding(
      padding:
      const EdgeInsets.only(
        bottom: 10,
      ),

      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
            ),
          ),

          Text(
            value,

            style:
            const TextStyle(
              fontWeight:
              FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}