import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';

class JobLocationCard extends StatelessWidget {
  final ActiveJob job;

  final VoidCallback? onOpenMap;

  const JobLocationCard({
    super.key,
    required this.job,
    this.onOpenMap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(
        20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration:
                BoxDecoration(
                  color: AppTheme
                      .primaryColor
                      .withOpacity(
                    0.1,
                  ),
                  borderRadius:
                  BorderRadius
                      .circular(
                    14,
                  ),
                ),
                child: const Icon(
                  Icons.location_on,
                  color: AppTheme
                      .primaryColor,
                ),
              ),

              const SizedBox(
                width: 14,
              ),

              const Expanded(
                child: Text(
                  'Location Details',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                    FontWeight.bold,
                    color: AppTheme
                        .textPrimary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 20,
          ),

          _buildInfoRow(
            icon:
            Icons.person_outline,
            title:
            'Recipient',
            value:
            job.recipientName,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.location_city,
            title: 'Address',
            value:
            job.recipientAddress,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.straighten,
            title: 'Distance',
            value:
            '${job.distanceKm.toStringAsFixed(1)} km',
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.access_time,
            title:
            'Estimated Arrival',
            value:
            '${job.estimatedArrival.inMinutes} minutes',
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.pin_drop_outlined,
            title:
            'Coordinates',
            value:
            '${job.recipientLatitude.toStringAsFixed(6)}, '
                '${job.recipientLongitude.toStringAsFixed(6)}',
          ),

          const SizedBox(
            height: 24,
          ),

          SizedBox(
            width:
            double.infinity,
            child:
            ElevatedButton.icon(
              onPressed:
              onOpenMap,
              style:
              ElevatedButton
                  .styleFrom(
                backgroundColor:
                AppTheme
                    .primaryColor,
                foregroundColor:
                Colors.white,
                elevation: 0,
                padding:
                const EdgeInsets.symmetric(
                  vertical: 14,
                ),
                shape:
                RoundedRectangleBorder(
                  borderRadius:
                  BorderRadius.circular(
                    14,
                  ),
                ),
              ),
              icon: const Icon(
                Icons.map_outlined,
              ),
              label: const Text(
                'Open in Maps',
                style: TextStyle(
                  fontWeight:
                  FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color: AppTheme
              .textSecondary,
          size: 22,
        ),

        const SizedBox(
          width: 14,
        ),

        Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,
            children: [
              Text(
                title,
                style:
                const TextStyle(
                  fontSize: 13,
                  color: AppTheme
                      .textSecondary,
                ),
              ),

              const SizedBox(
                height: 4,
              ),

              Text(
                value,
                style:
                const TextStyle(
                  fontSize: 15,
                  fontWeight:
                  FontWeight
                      .w600,
                  color: AppTheme
                      .textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}