import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../mock/demo_active_jobs.dart';
import '../../mock/demo_job_requests.dart';
import '../../models/active_job.dart';
import 'widgets/active_job_card.dart';

class ActiveJobsScreen extends StatefulWidget {
  const ActiveJobsScreen({
    super.key,
  });

  @override
  State<ActiveJobsScreen> createState() =>
      _ActiveJobsScreenState();
}

class _ActiveJobsScreenState
    extends State<ActiveJobsScreen> {
  late List<ActiveJob> _jobs;

  @override
  void initState() {
    super.initState();

    _loadJobs();
  }

  void _loadJobs() {
    _jobs =
        DemoActiveJobs.activeJobs;

    // Fallback if active jobs are empty
    if (_jobs.isEmpty) {
      ScaffoldMessenger.maybeOf(
        context,
      )?.showSnackBar(
        const SnackBar(
          content: Text(
            'No active jobs found. Using accepted requests as fallback.',
          ),
        ),
      );

      // TODO:
      // Convert DemoJobRequests.acceptedRequests
      // into ActiveJob objects if needed.
      //
      // For now, we'll keep the list empty.
    }
  }

  Future<void> _refresh() async {
    await Future.delayed(
      const Duration(
        milliseconds: 600,
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _loadJobs();
    });
  }

  @override
  Widget build(
      BuildContext context,
      ) {
    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,

      appBar: AppBar(
        title: const Text(
          'Active Jobs',
        ),

        elevation: 0,
      ),

      body: RefreshIndicator(
        onRefresh: _refresh,

        child: _jobs.isEmpty
            ? _buildEmptyState()
            : Column(
          children: [
            _buildSummary(),

            Expanded(
              child: ListView.builder(
                physics:
                const BouncingScrollPhysics(),

                padding:
                const EdgeInsets.all(
                  20,
                ),

                itemCount:
                _jobs.length,

                itemBuilder: (
                    context,
                    index,
                    ) {
                  final job =
                  _jobs[index];

                  return ActiveJobCard(
                    job: job,

                    onStatusChanged:
                        () {
                      setState(
                            () {},
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummary() {
    final completed =
        _jobs.where(
              (job) =>
          job.isCompletedStatus,
        ).length;

    final inProgress =
        _jobs.where(
              (job) =>
          !job.isCompletedStatus,
        ).length;

    final totalBonus =
    _jobs.fold<double>(
      0,
          (
          total,
          job,
          ) =>
      total +
          job.bonusAmount,
    );

    return Container(
      margin:
      const EdgeInsets.all(
        20,
      ),

      padding:
      const EdgeInsets.all(
        20,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          24,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 16,

            offset:
            const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Row(
        children: [
          Expanded(
            child: _summaryItem(
              title:
              'Active',

              value:
              '$inProgress',

              color:
              Colors.blue,
            ),
          ),

          Expanded(
            child: _summaryItem(
              title:
              'Completed',

              value:
              '$completed',

              color:
              Colors.green,
            ),
          ),

          Expanded(
            child: _summaryItem(
              title:
              'Bonuses',

              value:
              '৳${totalBonus.toStringAsFixed(0)}',

              color:
              Colors.amber,
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryItem({
    required String title,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 12,

          height: 12,

          decoration:
          BoxDecoration(
            color: color,

            shape:
            BoxShape.circle,
          ),
        ),

        const SizedBox(
          height: 10,
        ),

        Text(
          value,

          style:
          const TextStyle(
            fontSize: 22,

            fontWeight:
            FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 4,
        ),

        Text(
          title,

          style:
          const TextStyle(
            color: AppTheme
                .textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      physics:
      const AlwaysScrollableScrollPhysics(),

      children: [
        SizedBox(
          height:
          MediaQuery.of(
            context,
          ).size.height *
              0.18,
        ),

        const Icon(
          Icons.work_outline,

          size: 90,

          color: Colors.grey,
        ),

        const SizedBox(
          height: 24,
        ),

        const Center(
          child: Text(
            'No Active Jobs',

            style: TextStyle(
              fontSize: 24,

              fontWeight:
              FontWeight.bold,
            ),
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        const Padding(
          padding:
          EdgeInsets.symmetric(
            horizontal: 40,
          ),

          child: Text(
            'Accepted jobs will appear here. Pull down to refresh.',

            textAlign:
            TextAlign.center,

            style: TextStyle(
              color: AppTheme
                  .textSecondary,

              fontSize: 16,
            ),
          ),
        ),

        const SizedBox(
          height: 30,
        ),

        Center(
          child: ElevatedButton.icon(
            onPressed: () {
              _refresh();
            },

            icon: const Icon(
              Icons.refresh,
            ),

            label: const Text(
              'Refresh',
            ),
          ),
        ),
      ],
    );
  }
}