import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../models/activity_item.dart';

import '../../providers/jobs_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../providers/worker_provider.dart';

import '../../screens/earnings/earnings_history_screen.dart';
import '../../screens/jobs/active_jobs_screen.dart';
import '../../screens/jobs/pending_jobs_screen.dart';
import '../../screens/notifications/notifications_screen.dart';
import '../../screens/profile/edit_profile_screen.dart';

import 'widgets/dashboard_quick_actions.dart';
import 'widgets/dashboard_recent_activity.dart';
import 'widgets/dashboard_stats_card.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() =>
      _DashboardScreenState();
}

class _DashboardScreenState
    extends State<DashboardScreen> {
  Future<void> _handleRefresh() async {
    try {
      await Future.wait([
        context
            .read<WorkerProvider>()
            .loadWorker(1),

        context
            .read<JobsProvider>()
            .fetchJobs(),

        context
            .read<NotificationsProvider>()
            .fetchNotifications(),
      ]);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final workerProvider =
    context.watch<WorkerProvider>();

    final worker =
        workerProvider.currentWorker;

    final jobsProvider =
    context.watch<JobsProvider>();

    final notificationsProvider =
    context.watch<NotificationsProvider>();

    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _handleRefresh,
          child: ListView(
            padding:
            const EdgeInsets.all(20),
            physics:
            const AlwaysScrollableScrollPhysics(),
            children: [
              if (worker != null) ...[
                Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor:
                      AppTheme
                          .primaryColor
                          .withValues(
                        alpha: 0.1,
                      ),
                      child: const Icon(
                        Icons.person,
                        size: 28,
                        color: AppTheme
                            .primaryColor,
                      ),
                    ),

                    const SizedBox(
                      width: 12,
                    ),

                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment
                            .start,
                        children: [
                          Text(
                            'Good Morning, ${worker.fullName}',
                            style:
                            const TextStyle(
                              fontSize: 20,
                              fontWeight:
                              FontWeight
                                  .bold,
                              color: AppTheme
                                  .textPrimary,
                            ),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Text(
                            '${worker.tier} Partner',
                            style:
                            const TextStyle(
                              fontSize: 14,
                              color: AppTheme
                                  .textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),

                    Row(
                      children: [
                        const Icon(
                          Icons.star,
                          color:
                          Colors.amber,
                          size: 18,
                        ),
                        const SizedBox(
                          width: 4,
                        ),
                        Text(
                          worker.rating
                              .toStringAsFixed(
                              1),
                          style:
                          const TextStyle(
                            fontWeight:
                            FontWeight
                                .bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                const SizedBox(
                  height: 24,
                ),
              ],

              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  DashboardStatsCard(
                    title: 'Active Jobs',
                    value: jobsProvider
                        .activeCount
                        .toString(),
                    icon: Icons.work,
                    color: Colors.blue,
                  ),
                  DashboardStatsCard(
                    title:
                    'Pending Requests',
                    value: jobsProvider
                        .pendingCount
                        .toString(),
                    icon: Icons
                        .pending_actions,
                    color:
                    Colors.orange,
                  ),
                  DashboardStatsCard(
                    title:
                    'Today\'s Earnings',
                    value:
                    '৳${jobsProvider.todayEarnings.toStringAsFixed(0)}',
                    icon: Icons
                        .attach_money,
                    color:
                    Colors.green,
                  ),
                  DashboardStatsCard(
                    title:
                    'Wallet Balance',
                    value: worker == null
                        ? '0.00'
                        : worker
                        .walletBalance
                        .toStringAsFixed(
                        2),
                    icon: Icons
                        .account_balance_wallet,
                    color:
                    Colors.purple,
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  DashboardStatsCard(
                    title:
                    'Completed Jobs',
                    value: jobsProvider
                        .completedCount
                        .toString(),
                    icon: Icons
                        .check_circle,
                    color:
                    Colors.teal,
                  ),
                  DashboardStatsCard(
                    title:
                    'Bonus Earned',
                    value:
                    '৳${jobsProvider.bonusEarned.toStringAsFixed(0)}',
                    icon: Icons
                        .card_giftcard,
                    color:
                    Colors.pink,
                  ),
                  DashboardStatsCard(
                    title: 'Points',
                    value: worker == null
                        ? '0'
                        : worker.points
                        .toString(),
                    icon: Icons
                        .emoji_events,
                    color: AppTheme
                        .primaryColor,
                  ),
                  DashboardStatsCard(
                    title: 'Tier',
                    value: worker == null
                        ? ''
                        : worker.tier,
                    icon: Icons.star,
                    color: AppTheme
                        .primaryColor,
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              DashboardQuickActions(
                onPendingJobs: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const PendingJobsScreen(),
                    ),
                  );
                },
                onActiveJobs: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const ActiveJobsScreen(),
                    ),
                  );
                },
                onEarnings: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const EarningsHistoryScreen(),
                    ),
                  );
                },
                onEditProfile: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const EditProfileScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(
                height: 24,
              ),

              DashboardRecentActivity(
                notifications:
                notificationsProvider
                    .latest
                    .map(
                      (notification) =>
                      ActivityItem(
                        id:
                        notification.id,
                        title:
                        notification
                            .title,
                        subtitle:
                        notification
                            .message,
                        createdAt:
                        notification
                            .createdAt,
                        icon:
                        notification
                            .icon,
                        color:
                        notification
                            .notificationColor,
                      ),
                )
                    .toList(),

                completedJobs:
                jobsProvider
                    .recentCompleted
                    .map(
                      (job) =>
                      ActivityItem(
                        id: job.id,
                        title: job
                            .serviceName,
                        subtitle:
                        '${job.customerName} • ৳${job.totalEarnings.toStringAsFixed(0)}',
                        createdAt:
                        job.completedAt ??
                            DateTime
                                .now(),
                        icon: Icons
                            .check_circle,
                        color:
                        Colors.green,
                      ),
                )
                    .toList(),

                onViewAllNotifications:
                    () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const NotificationsScreen(),
                    ),
                  );
                },

                onViewAllCompletedJobs:
                    () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const ActiveJobsScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}