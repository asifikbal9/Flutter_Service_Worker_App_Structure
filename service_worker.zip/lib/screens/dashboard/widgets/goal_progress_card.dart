import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class GoalProgressCard extends StatelessWidget {
  final int completedJobs;

  final int weeklyGoal;

  final double bonusReward;

  const GoalProgressCard({
    super.key,
    required this.completedJobs,
    required this.weeklyGoal,
    required this.bonusReward,
  });

  @override
  Widget build(BuildContext context) {
    final remainingJobs =
    (weeklyGoal - completedJobs)
        .clamp(0, weeklyGoal);

    final progress =
    weeklyGoal == 0
        ? 0.0
        : (completedJobs / weeklyGoal)
        .clamp(0.0, 1.0);

    final goalAchieved =
        completedJobs >= weeklyGoal;

    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 800,
      ),

      curve: Curves.easeOutCubic,

      tween: Tween(
        begin: 0,
        end: progress,
      ),

      builder: (
          context,
          animatedProgress,
          child,
          ) {
        return Container(
          padding: const EdgeInsets.all(
            22,
          ),

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
            BorderRadius.circular(
              28,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(
                  0.05,
                ),

                blurRadius: 18,

                offset: const Offset(
                  0,
                  8,
                ),
              ),
            ],
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,

            children: [
              Row(
                children: [
                  Container(
                    width: 56,

                    height: 56,

                    decoration:
                    BoxDecoration(
                      color: AppTheme
                          .primaryColor
                          .withOpacity(
                        0.12,
                      ),

                      borderRadius:
                      BorderRadius
                          .circular(
                        18,
                      ),
                    ),

                    child: const Icon(
                      Icons.flag_outlined,

                      color: AppTheme
                          .primaryColor,

                      size: 30,
                    ),
                  ),

                  const SizedBox(
                    width: 16,
                  ),

                  const Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        Text(
                          'Weekly Goal',

                          style: TextStyle(
                            fontSize: 20,

                            fontWeight:
                            FontWeight
                                .bold,

                            color: AppTheme
                                .textPrimary,
                          ),
                        ),

                        SizedBox(
                          height: 4,
                        ),

                        Text(
                          'Complete jobs to unlock rewards.',

                          style: TextStyle(
                            color: AppTheme
                                .textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  Expanded(
                    child: _buildStat(
                      title:
                      'Completed',

                      value:
                      '$completedJobs',
                    ),
                  ),

                  Expanded(
                    child: _buildStat(
                      title:
                      'Goal',

                      value:
                      '$weeklyGoal',
                    ),
                  ),

                  Expanded(
                    child: _buildStat(
                      title:
                      'Remaining',

                      value:
                      '$remainingJobs',
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Goal Progress',

                      style: TextStyle(
                        fontWeight:
                        FontWeight
                            .w600,

                        color: AppTheme
                            .textPrimary,
                      ),
                    ),
                  ),

                  Text(
                    '${(animatedProgress * 100).toInt()}%',

                    style: const TextStyle(
                      color: AppTheme
                          .primaryColor,

                      fontWeight:
                      FontWeight.bold,
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 10,
              ),

              ClipRRect(
                borderRadius:
                BorderRadius.circular(
                  12,
                ),

                child:
                LinearProgressIndicator(
                  value:
                  animatedProgress,

                  minHeight: 12,

                  backgroundColor:
                  Colors.grey.shade200,

                  valueColor:
                  const AlwaysStoppedAnimation(
                    AppTheme.primaryColor,
                  ),
                ),
              ),

              const SizedBox(
                height: 24,
              ),

              Container(
                padding:
                const EdgeInsets.all(
                  18,
                ),

                decoration:
                BoxDecoration(
                  color: goalAchieved
                      ? Colors.green
                      .withOpacity(
                    0.10,
                  )
                      : Colors.amber
                      .withOpacity(
                    0.10,
                  ),

                  borderRadius:
                  BorderRadius
                      .circular(
                    18,
                  ),
                ),

                child: Row(
                  children: [
                    Icon(
                      goalAchieved
                          ? Icons
                          .verified
                          : Icons
                          .card_giftcard,

                      color:
                      goalAchieved
                          ? Colors
                          .green
                          : Colors
                          .orange,
                    ),

                    const SizedBox(
                      width: 12,
                    ),

                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment
                            .start,

                        children: [
                          Text(
                            goalAchieved
                                ? 'Goal Achieved!'
                                : 'Bonus Reward',

                            style:
                            TextStyle(
                              color: goalAchieved
                                  ? Colors
                                  .green
                                  : Colors
                                  .orange,

                              fontWeight:
                              FontWeight
                                  .bold,
                            ),
                          ),

                          const SizedBox(
                            height: 4,
                          ),

                          Text(
                            goalAchieved
                                ? 'You have unlocked your weekly bonus.'
                                : '$remainingJobs more job${remainingJobs == 1 ? '' : 's'} needed to unlock ৳${bonusReward.toStringAsFixed(0)}.',

                            style:
                            const TextStyle(
                              color: AppTheme
                                  .textSecondary,

                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStat({
    required String title,
    required String value,
  }) {
    return Column(
      children: [
        Text(
          value,

          style: const TextStyle(
            fontSize: 26,

            fontWeight:
            FontWeight.w800,

            color:
            AppTheme.textPrimary,
          ),
        ),

        const SizedBox(
          height: 4,
        ),

        Text(
          title,

          style: const TextStyle(
            color:
            AppTheme.textSecondary,

            fontSize: 13,
          ),
        ),
      ],
    );
  }
}