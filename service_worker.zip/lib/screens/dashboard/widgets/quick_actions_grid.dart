import 'package:flutter/material.dart';

import 'quick_action_tile.dart';

class QuickActionsGrid extends StatelessWidget {
  final VoidCallback? onPendingJobsTap;

  final VoidCallback? onActiveJobsTap;

  final VoidCallback? onMapTap;

  final VoidCallback? onWalletTap;

  final VoidCallback? onNotificationsTap;

  final VoidCallback? onProfileTap;

  final VoidCallback? onBonusCenterTap;

  final VoidCallback? onSettingsTap;

  final int pendingJobsCount;

  final int notificationsCount;

  const QuickActionsGrid({
    super.key,
    this.onPendingJobsTap,
    this.onActiveJobsTap,
    this.onMapTap,
    this.onWalletTap,
    this.onNotificationsTap,
    this.onProfileTap,
    this.onBonusCenterTap,
    this.onSettingsTap,
    this.pendingJobsCount = 0,
    this.notificationsCount = 0,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,

      physics:
      const NeverScrollableScrollPhysics(),

      crossAxisCount: 2,

      mainAxisSpacing: 16,

      crossAxisSpacing: 16,

      childAspectRatio: 1.15,

      children: [
        QuickActionTile(
          title: 'Pending Jobs',

          subtitle:
          'Review incoming requests.',

          icon:
          Icons.assignment_outlined,

          iconColor:
          Colors.orange,

          showBadge:
          pendingJobsCount > 0,

          badgeText:
          pendingJobsCount
              .toString(),

          onTap:
          onPendingJobsTap,
        ),

        QuickActionTile(
          title: 'Active Jobs',

          subtitle:
          'Manage ongoing services.',

          icon:
          Icons.work_outline,

          iconColor:
          Colors.green,

          onTap:
          onActiveJobsTap,
        ),

        QuickActionTile(
          title: 'Open Map',

          subtitle:
          'Track routes and destinations.',

          icon:
          Icons.map_outlined,

          iconColor:
          Colors.blue,

          onTap: onMapTap,
        ),

        QuickActionTile(
          title: 'Wallet',

          subtitle:
          'View earnings and bonuses.',

          icon: Icons
              .account_balance_wallet_outlined,

          iconColor:
          Colors.purple,

          onTap:
          onWalletTap,
        ),

        QuickActionTile(
          title: 'Notifications',

          subtitle:
          'Stay updated instantly.',

          icon:
          Icons.notifications_outlined,

          iconColor:
          Colors.red,

          showBadge:
          notificationsCount >
              0,

          badgeText:
          notificationsCount
              .toString(),

          onTap:
          onNotificationsTap,
        ),

        QuickActionTile(
          title: 'Profile',

          subtitle:
          'Manage personal details.',

          icon:
          Icons.person_outline,

          iconColor:
          Colors.teal,

          onTap:
          onProfileTap,
        ),

        QuickActionTile(
          title: 'Bonus Center',

          subtitle:
          'Explore bonus opportunities.',

          icon:
          Icons.card_giftcard,

          iconColor:
          Colors.amber,

          onTap:
          onBonusCenterTap,
        ),

        QuickActionTile(
          title: 'Settings',

          subtitle:
          'Customize your experience.',

          icon:
          Icons.settings_outlined,

          iconColor:
          Colors.grey,

          onTap:
          onSettingsTap,
        ),
      ],
    );
  }
}