import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class DashboardQuickActions extends StatelessWidget {
  final VoidCallback? onPendingJobs;

  final VoidCallback? onActiveJobs;

  final VoidCallback? onEarnings;

  final VoidCallback? onEditProfile;

  const DashboardQuickActions({
    super.key,
    this.onPendingJobs,
    this.onActiveJobs,
    this.onEarnings,
    this.onEditProfile,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Container(
      padding: const EdgeInsets.all(
        20,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 16,

            offset: const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          const Text(
            'Quick Actions',

            style: TextStyle(
              fontSize: 20,

              fontWeight:
              FontWeight.bold,

              color:
              AppTheme.textPrimary,
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          Row(
            children: [
              Expanded(
                child:
                _QuickActionButton(
                  icon:
                  Icons.pending_actions,

                  title:
                  'Pending\nJobs',

                  color:
                  Colors.orange,

                  onTap:
                  onPendingJobs,
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              Expanded(
                child:
                _QuickActionButton(
                  icon:
                  Icons.work,

                  title:
                  'Active\nJobs',

                  color:
                  Colors.blue,

                  onTap:
                  onActiveJobs,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 12,
          ),

          Row(
            children: [
              Expanded(
                child:
                _QuickActionButton(
                  icon: Icons
                      .account_balance_wallet,

                  title:
                  'View\nEarnings',

                  color:
                  Colors.green,

                  onTap:
                  onEarnings,
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              Expanded(
                child:
                _QuickActionButton(
                  icon:
                  Icons.person,

                  title:
                  'Edit\nProfile',

                  color:
                  AppTheme
                      .primaryColor,

                  onTap:
                  onEditProfile,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _QuickActionButton
    extends StatelessWidget {
  final IconData icon;

  final String title;

  final Color color;

  final VoidCallback? onTap;

  const _QuickActionButton({
    required this.icon,
    required this.title,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Material(
      color: Colors.transparent,

      child: InkWell(
        onTap: onTap,

        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusMD,
        ),

        child: Container(
          padding:
          const EdgeInsets.symmetric(
            vertical: 20,
            horizontal: 12,
          ),

          decoration: BoxDecoration(
            color:
            color.withOpacity(
              0.08,
            ),

            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusMD,
            ),

            border: Border.all(
              color:
              color.withOpacity(
                0.15,
              ),
            ),
          ),

          child: Column(
            children: [
              Container(
                width: 52,

                height: 52,

                decoration:
                BoxDecoration(
                  color: color
                      .withOpacity(
                    0.12,
                  ),

                  shape:
                  BoxShape.circle,
                ),

                child: Icon(
                  icon,

                  color: color,

                  size: 28,
                ),
              ),

              const SizedBox(
                height: 14,
              ),

              Text(
                title,

                textAlign:
                TextAlign.center,

                style:
                const TextStyle(
                  fontSize: 13,

                  fontWeight:
                  FontWeight.w600,

                  color: AppTheme
                      .textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}