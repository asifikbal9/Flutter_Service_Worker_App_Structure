import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class EarningsCard extends StatelessWidget {
  final double todayEarnings;

  final double bonusEarned;

  final double availableBalance;

  final double weeklyGoal;

  final VoidCallback? onWithdraw;

  const EarningsCard({
    super.key,
    required this.todayEarnings,
    required this.bonusEarned,
    required this.availableBalance,
    required this.weeklyGoal,
    this.onWithdraw,
  });

  @override
  Widget build(BuildContext context) {
    final progress =
    weeklyGoal <= 0
        ? 0.0
        : (todayEarnings / weeklyGoal)
        .clamp(0.0, 1.0);

    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 700,
      ),

      tween: Tween(
        begin: 0,
        end: progress,
      ),

      curve: Curves.easeOutCubic,

      builder: (
          context,
          animatedProgress,
          child,
          ) {
        return Container(
          padding: const EdgeInsets.all(
            22,
          ),

          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,

              end: Alignment.bottomRight,

              colors: [
                AppTheme.primaryColor,
                AppTheme.primaryDarkColor,
              ],
            ),

            borderRadius:
            BorderRadius.circular(
              28,
            ),

            boxShadow: [
              BoxShadow(
                color: AppTheme.primaryColor
                    .withOpacity(
                  0.25,
                ),

                blurRadius: 20,

                offset: const Offset(
                  0,
                  10,
                ),
              ),
            ],
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,

            children: [
              Row(
                children: [
                  const Icon(
                    Icons.account_balance_wallet,

                    color: Colors.white,

                    size: 30,
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  const Expanded(
                    child: Text(
                      'Earnings Overview',

                      style: TextStyle(
                        color: Colors.white,

                        fontSize: 20,

                        fontWeight:
                        FontWeight.bold,
                      ),
                    ),
                  ),

                  TextButton.icon(
                    onPressed:
                    onWithdraw,

                    style:
                    TextButton.styleFrom(
                      foregroundColor:
                      Colors.white,
                    ),

                    icon: const Icon(
                      Icons.payments_outlined,
                    ),

                    label: const Text(
                      'Withdraw',
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 28,
              ),

              Text(
                '৳${todayEarnings.toStringAsFixed(0)}',

                style: const TextStyle(
                  color: Colors.white,

                  fontSize: 38,

                  fontWeight:
                  FontWeight.w800,
                ),
              ),

              const SizedBox(
                height: 6,
              ),

              const Text(
                'Today\'s Earnings',

                style: TextStyle(
                  color: Colors.white70,

                  fontSize: 15,
                ),
              ),

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  Expanded(
                    child: _buildInfoTile(
                      icon:
                      Icons.card_giftcard,

                      title:
                      'Bonus Earned',

                      value:
                      '৳${bonusEarned.toStringAsFixed(0)}',
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: _buildInfoTile(
                      icon:
                      Icons.savings_outlined,

                      title:
                      'Balance',

                      value:
                      '৳${availableBalance.toStringAsFixed(0)}',
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Daily Goal Progress',

                      style: TextStyle(
                        color: Colors.white,

                        fontWeight:
                        FontWeight.w600,
                      ),
                    ),
                  ),

                  Text(
                    '${(animatedProgress * 100).toInt()}%',

                    style: const TextStyle(
                      color: Colors.white,

                      fontWeight:
                      FontWeight.bold,
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 10,
              ),

              ClipRRect(
                borderRadius:
                BorderRadius.circular(
                  12,
                ),

                child:
                LinearProgressIndicator(
                  value:
                  animatedProgress,

                  minHeight: 10,

                  backgroundColor:
                  Colors.white24,

                  valueColor:
                  const AlwaysStoppedAnimation(
                    Colors.white,
                  ),
                ),
              ),

              const SizedBox(
                height: 10,
              ),

              Text(
                'Goal: ৳${weeklyGoal.toStringAsFixed(0)}',

                style: const TextStyle(
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInfoTile({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color: Colors.white
            .withOpacity(
          0.12,
        ),

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Icon(
            icon,

            color: Colors.white,
          ),

          const SizedBox(
            height: 12,
          ),

          Text(
            value,

            style: const TextStyle(
              color: Colors.white,

              fontSize: 20,

              fontWeight:
              FontWeight.bold,
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            title,

            style: const TextStyle(
              color: Colors.white70,

              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}