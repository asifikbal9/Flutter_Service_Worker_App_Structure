import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../widgets/inputs/app_text_field.dart';
import '../../../widgets/inputs/password_field.dart';

class RegisterFormWidget extends StatelessWidget {
  final GlobalKey<FormState> formKey;

  final TextEditingController fullNameController;

  final TextEditingController mobileController;

  final TextEditingController emailController;

  final TextEditingController addressController;

  final TextEditingController experienceController;

  final TextEditingController skillsController;

  final TextEditingController nidController;

  final TextEditingController passwordController;

  final TextEditingController confirmPasswordController;

  final String? selectedTrade;

  final ValueChanged<String?> onTradeChanged;

  const RegisterFormWidget({
    super.key,
    required this.formKey,
    required this.fullNameController,
    required this.mobileController,
    required this.emailController,
    required this.addressController,
    required this.experienceController,
    required this.skillsController,
    required this.nidController,
    required this.passwordController,
    required this.confirmPasswordController,
    required this.selectedTrade,
    required this.onTradeChanged,
  });

  static const List<String> tradeCategories = [
    'Electrician',
    'Plumber',
    'AC Technician',
    'Cleaner',
    'Painter',
    'Carpenter',
    'Home Nurse',
    'IT Support',
    'Mechanic',
    'Other',
  ];

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,

      child: Column(
        children: [
          AppTextField(
            controller: fullNameController,

            label: 'Full Name',

            hintText: 'Enter your full name',

            prefixIcon: Icons.person_outline,

            textCapitalization:
            TextCapitalization.words,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter your name';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller: mobileController,

            label: 'Mobile Number',

            hintText: '01XXXXXXXXX',

            prefixIcon: Icons.phone_outlined,

            keyboardType:
            TextInputType.phone,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter mobile number';
              }

              if (value.trim().length < 11) {
                return 'Enter valid mobile number';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller: emailController,

            label: 'Email Address',

            hintText: 'example@email.com',

            prefixIcon: Icons.email_outlined,

            keyboardType:
            TextInputType.emailAddress,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter email';
              }

              if (!value.contains('@')) {
                return 'Enter valid email';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller: addressController,

            label: 'Address',

            hintText:
            'Enter your current address',

            prefixIcon:
            Icons.location_on_outlined,

            maxLines: 3,

            textCapitalization:
            TextCapitalization.sentences,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter address';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          DropdownButtonFormField<String>(
            value: selectedTrade,

            decoration: InputDecoration(
              labelText: 'Trade Category',

              prefixIcon: const Icon(
                Icons.work_outline,
              ),

              filled: true,

              fillColor: Colors.white,

              border: OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(
                  AppTheme.radiusLG,
                ),
              ),

              enabledBorder:
              OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(
                  AppTheme.radiusLG,
                ),

                borderSide:
                const BorderSide(
                  color:
                  AppTheme.borderColor,
                ),
              ),

              focusedBorder:
              OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(
                  AppTheme.radiusLG,
                ),

                borderSide:
                const BorderSide(
                  color: AppTheme
                      .primaryColor,

                  width: 2,
                ),
              ),
            ),

            items: tradeCategories
                .map(
                  (trade) =>
                  DropdownMenuItem(
                    value: trade,

                    child: Text(
                      trade,
                    ),
                  ),
            )
                .toList(),

            onChanged: onTradeChanged,

            validator: (value) {
              if (value == null) {
                return 'Select your trade';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller:
            experienceController,

            label: 'Experience (Years)',

            hintText:
            'How many years?',

            prefixIcon:
            Icons.workspace_premium,

            keyboardType:
            TextInputType.number,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Enter experience';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller: skillsController,

            label: 'Skills',

            hintText:
            'AC Repair, Wiring, Installation',

            prefixIcon:
            Icons.build_outlined,

            maxLines: 2,

            textCapitalization:
            TextCapitalization.words,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter skills';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          AppTextField(
            controller: nidController,

            label: 'NID Number',

            hintText:
            'Enter National ID number',

            prefixIcon:
            Icons.badge_outlined,

            keyboardType:
            TextInputType.number,

            validator: (value) {
              if (value == null ||
                  value.trim().isEmpty) {
                return 'Please enter NID';
              }

              return null;
            },
          ),

          const SizedBox(
            height: 16,
          ),

          PasswordField(
            controller:
            passwordController,

            label: 'Password',

            hintText:
            'Create a password',
          ),

          const SizedBox(
            height: 16,
          ),

          PasswordField(
            controller:
            confirmPasswordController,

            label: 'Confirm Password',

            hintText:
            'Re-enter password',

            validator: (value) {
              if (value == null ||
                  value.isEmpty) {
                return 'Please confirm password';
              }

              if (value !=
                  passwordController.text) {
                return 'Passwords do not match';
              }

              return null;
            },
          ),
        ],
      ),
    );
  }
}