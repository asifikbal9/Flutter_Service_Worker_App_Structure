import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class RegisterHeaderWidget extends StatelessWidget {
  const RegisterHeaderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 700,
      ),
      curve: Curves.easeOutCubic,
      tween: Tween(
        begin: 0,
        end: 1,
      ),
      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            30 * (1 - value),
          ),
          child: Opacity(
            opacity: value,
            child: child,
          ),
        );
      },
      child: Column(
        children: [
          Center(
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                gradient:
                const LinearGradient(
                  begin:
                  Alignment.topLeft,
                  end: Alignment
                      .bottomRight,
                  colors: [
                    AppTheme
                        .primaryColor,
                    AppTheme
                        .primaryDarkColor,
                  ],
                ),
                borderRadius:
                BorderRadius.circular(
                  30,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme
                        .primaryColor
                        .withOpacity(
                      0.25,
                    ),
                    blurRadius: 20,
                    offset:
                    const Offset(
                      0,
                      10,
                    ),
                  ),
                ],
              ),
              child: const Icon(
                Icons.engineering,
                color: Colors.white,
                size: 52,
              ),
            ),
          ),

          const SizedBox(
            height: 24,
          ),

          const Text(
            'Become a Service Partner',
            textAlign:
            TextAlign.center,
            style: TextStyle(
              fontSize: 28,
              fontWeight:
              FontWeight.w800,
              color:
              AppTheme.textPrimary,
            ),
          ),

          const SizedBox(
            height: 10,
          ),

          Text(
            'Join our professional workforce and start earning from your skills.',
            textAlign:
            TextAlign.center,
            style: TextStyle(
              fontSize: 15,
              height: 1.5,
              color: AppTheme
                  .textSecondary,
            ),
          ),

          const SizedBox(
            height: 24,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              16,
            ),
            decoration: BoxDecoration(
              color: AppTheme
                  .primaryColor
                  .withOpacity(
                0.08,
              ),
              borderRadius:
              BorderRadius.circular(
                20,
              ),
            ),
            child: Row(
              children: const [
                Icon(
                  Icons.workspace_premium,
                  color: AppTheme
                      .primaryColor,
                ),

                SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Text(
                    'Verified workers receive more jobs, bonuses and higher customer trust.',
                    style: TextStyle(
                      fontSize: 13,
                      color: AppTheme
                          .textPrimary,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(
            height: 30,
          ),
        ],
      ),
    );
  }
}