import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../widgets/buttons/gradient_button.dart';

class RegisterFooterWidget extends StatelessWidget {
  final bool isLoading;

  final VoidCallback? onRegister;

  final VoidCallback? onLogin;

  const RegisterFooterWidget({
    super.key,
    required this.isLoading,
    required this.onRegister,
    required this.onLogin,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GradientButton(
          text: 'Become a Service Partner',
          icon: Icons.verified_user,
          isLoading: isLoading,
          onPressed: onRegister,
        ),

        const SizedBox(
          height: 24,
        ),

        Row(
          children: [
            Expanded(
              child: Divider(
                color: Colors.grey.shade300,
                thickness: 1,
              ),
            ),

            Padding(
              padding:
              const EdgeInsets.symmetric(
                horizontal: 16,
              ),
              child: Text(
                'OR',
                style: TextStyle(
                  color:
                  Colors.grey.shade600,
                  fontWeight:
                  FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),

            Expanded(
              child: Divider(
                color: Colors.grey.shade300,
                thickness: 1,
              ),
            ),
          ],
        ),

        const SizedBox(
          height: 24,
        ),

        Container(
          padding:
          const EdgeInsets.symmetric(
            vertical: 18,
            horizontal: 20,
          ),

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            border: Border.all(
              color:
              AppTheme.borderColor,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(
                  0.04,
                ),

                blurRadius: 12,

                offset:
                const Offset(
                  0,
                  4,
                ),
              ),
            ],
          ),

          child: Row(
            mainAxisAlignment:
            MainAxisAlignment.center,

            children: [
              const Text(
                'Already have an account?',
                style: TextStyle(
                  color:
                  AppTheme.textSecondary,
                  fontSize: 14,
                ),
              ),

              TextButton(
                onPressed: onLogin,

                child: const Text(
                  'Login',
                  style: TextStyle(
                    color: AppTheme
                        .primaryColor,

                    fontWeight:
                    FontWeight.bold,

                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        Text(
          'By continuing, you agree to our Terms of Service and Privacy Policy.',
          textAlign:
          TextAlign.center,

          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
            height: 1.5,
          ),
        ),

        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}