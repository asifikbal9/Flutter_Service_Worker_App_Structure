import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/buttons/gradient_button.dart';
import '../../widgets/inputs/app_text_field.dart';
import '../../widgets/inputs/password_field.dart';
import '../../widgets/worker_bottom_navigation.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({
    super.key,
  });

  @override
  State<LoginScreen> createState() =>
      _LoginScreenState();
}

class _LoginScreenState
    extends State<LoginScreen> {
  final _formKey =
  GlobalKey<FormState>();

  final _emailController =
  TextEditingController();

  final _passwordController =
  TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();

    _passwordController.dispose();

    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    final authProvider =
    context.read<AuthProvider>();

    final success =
    await authProvider.login(
      email:
      _emailController.text
          .trim(),
      password:
      _passwordController.text,
    );

    if (!mounted) {
      return;
    }

    if (success) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) =>
          const WorkerBottomNavigation(),
        ),
            (route) => false,
      );
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        SnackBar(
          content: Text(
            authProvider
                .errorMessage ??
                'Invalid credentials.',
          ),
          backgroundColor:
          AppTheme.errorColor,
        ),
      );
    }
  }

  @override
  Widget build(
      BuildContext context) {
    final authProvider =
    context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,

      body: SafeArea(
        child:
        SingleChildScrollView(
          padding:
          const EdgeInsets.all(
            24,
          ),

          child: Form(
            key: _formKey,

            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .stretch,

              children: [
                const SizedBox(
                  height: 40,
                ),

                TweenAnimationBuilder<
                    double>(
                  duration:
                  const Duration(
                    milliseconds:
                    700,
                  ),

                  tween: Tween(
                    begin: 0,
                    end: 1,
                  ),

                  curve: Curves
                      .easeOutCubic,

                  builder: (
                      context,
                      value,
                      child,
                      ) {
                    return Transform
                        .translate(
                      offset: Offset(
                        0,
                        30 *
                            (1 -
                                value),
                      ),

                      child: Opacity(
                        opacity:
                        value,

                        child:
                        child,
                      ),
                    );
                  },

                  child: Column(
                    children: [
                      Container(
                        width: 100,

                        height: 100,

                        decoration:
                        BoxDecoration(
                          gradient:
                          const LinearGradient(
                            colors: [
                              AppTheme
                                  .primaryColor,
                              AppTheme
                                  .primaryDarkColor,
                            ],
                          ),

                          borderRadius:
                          BorderRadius.circular(
                            28,
                          ),

                          boxShadow: [
                            BoxShadow(
                              color: AppTheme
                                  .primaryColor
                                  .withOpacity(
                                0.25,
                              ),

                              blurRadius:
                              20,

                              offset:
                              const Offset(
                                0,
                                10,
                              ),
                            ),
                          ],
                        ),

                        child:
                        const Icon(
                          Icons
                              .engineering,

                          color:
                          Colors
                              .white,

                          size: 50,
                        ),
                      ),

                      const SizedBox(
                        height: 24,
                      ),

                      const Text(
                        'Welcome Back',

                        style:
                        TextStyle(
                          fontSize:
                          28,

                          fontWeight:
                          FontWeight
                              .w800,

                          color: AppTheme
                              .textPrimary,
                        ),
                      ),

                      const SizedBox(
                        height: 8,
                      ),

                      const Text(
                        'Login to continue your work journey.',

                        textAlign:
                        TextAlign
                            .center,

                        style:
                        TextStyle(
                          color: AppTheme
                              .textSecondary,

                          fontSize:
                          15,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  height: 40,
                ),

                AppTextField(
                  controller:
                  _emailController,

                  label:
                  'Email or Mobile',

                  hintText:
                  'Enter email or mobile number',

                  prefixIcon:
                  Icons.person_outline,

                  validator:
                      (value) {
                    if (value ==
                        null ||
                        value
                            .trim()
                            .isEmpty) {
                      return 'Please enter email or mobile';
                    }

                    return null;
                  },
                ),

                const SizedBox(
                  height: 20,
                ),

                PasswordField(
                  controller:
                  _passwordController,
                ),

                const SizedBox(
                  height: 32,
                ),

                GradientButton(
                  text: 'Login',

                  icon:
                  Icons.login,

                  isLoading:
                  authProvider
                      .isLoading,

                  onPressed:
                  _login,
                ),

                const SizedBox(
                  height: 28,
                ),

                Container(
                  padding:
                  const EdgeInsets.all(
                    18,
                  ),

                  decoration:
                  BoxDecoration(
                    color:
                    Colors.white,

                    borderRadius:
                    BorderRadius.circular(
                      AppTheme
                          .radiusLG,
                    ),

                    border:
                    Border.all(
                      color: AppTheme
                          .borderColor,
                    ),
                  ),

                  child: Row(
                    mainAxisAlignment:
                    MainAxisAlignment
                        .center,

                    children: [
                      const Text(
                        'New here?',

                        style:
                        TextStyle(
                          color: AppTheme
                              .textSecondary,
                        ),
                      ),

                      TextButton(
                        onPressed:
                            () {
                          Navigator.push(
                            context,

                            MaterialPageRoute(
                              builder:
                                  (_) =>
                              const RegisterScreen(),
                            ),
                          );
                        },

                        child:
                        const Text(
                          'Register as Partner',

                          style:
                          TextStyle(
                            fontWeight:
                            FontWeight.bold,

                            color: AppTheme
                                .primaryColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  height: 24,
                ),

                Text(
                  'Hard work is always respected.',

                  textAlign:
                  TextAlign.center,

                  style: TextStyle(
                    color: Colors
                        .grey.shade600,

                    fontStyle:
                    FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}