import 'package:flutter/material.dart';

import '../models/worker_notification.dart';

class DemoNotifications {
  static List<WorkerNotification> notifications = [
    WorkerNotification(
      id: 1,
      title: 'New Job Request',
      message:
      'You have received a new AC servicing request from Antor Shardar.',
      type: 'new_job',
      icon: Icons.work_outline,
      createdAt: DateTime.now().subtract(
        const Duration(minutes: 5),
      ),
      isRead: false,
      relatedJobId: 1,
      orderNumber: 'JR1001',
      hasAction: true,
      route: '/job-details',
    ),

    WorkerNotification(
      id: 2,
      title: 'Payment Released',
      message:
      '৳1,250 has been added to your wallet for completed plumbing work.',
      type: 'payment',
      icon: Icons.account_balance_wallet_outlined,
      createdAt: DateTime.now().subtract(
        const Duration(hours: 2),
      ),
      isRead: false,
      relatedJobId: 3,
      orderNumber: 'JR1003',
      hasAction: true,
      route: '/wallet',
    ),

    WorkerNotification(
      id: 3,
      title: 'Bonus Opportunity',
      message:
      'Complete 2 more jobs today to earn an extra ৳500 bonus.',
      type: 'bonus_job',
      icon: Icons.card_giftcard,
      createdAt: DateTime.now().subtract(
        const Duration(hours: 4),
      ),
      isRead: false,
      relatedJobId: null,
      orderNumber: null,
      hasAction: true,
      route: '/bonus-jobs',
    ),

    WorkerNotification(
      id: 4,
      title: 'Customer Rated You',
      message:
      'Rahim Uddin gave you a 5-star rating for excellent service.',
      type: 'rating',
      icon: Icons.star,
      createdAt: DateTime.now().subtract(
        const Duration(days: 1),
      ),
      isRead: true,
      relatedJobId: 1,
      orderNumber: 'SLA-1001',
      hasAction: true,
      route: '/ratings',
    ),

    WorkerNotification(
      id: 5,
      title: 'Job Cancelled',
      message:
      'A customer cancelled the electrician booking scheduled for today.',
      type: 'cancelled_job',
      icon: Icons.cancel_outlined,
      createdAt: DateTime.now().subtract(
        const Duration(days: 1, hours: 3),
      ),
      isRead: true,
      relatedJobId: 4,
      orderNumber: 'JR1004',
      hasAction: true,
      route: '/job-requests',
    ),

    WorkerNotification(
      id: 6,
      title: 'Verification Reminder',
      message:
      'Please upload your updated NID information to maintain account verification.',
      type: 'verification',
      icon: Icons.verified_user_outlined,
      createdAt: DateTime.now().subtract(
        const Duration(days: 2),
      ),
      isRead: false,
      relatedJobId: null,
      orderNumber: null,
      hasAction: true,
      route: '/verification',
    ),

    WorkerNotification(
      id: 7,
      title: 'Weekly Performance',
      message:
      'Congratulations! You completed 18 jobs this week.',
      type: 'system',
      icon: Icons.emoji_events_outlined,
      createdAt: DateTime.now().subtract(
        const Duration(days: 3),
      ),
      isRead: true,
      relatedJobId: null,
      orderNumber: null,
      hasAction: true,
      route: '/dashboard',
    ),

    WorkerNotification(
      id: 8,
      title: 'Extra Side Job Available',
      message:
      'A nearby deep cleaning side job is available with a ৳300 bonus.',
      type: 'bonus_job',
      icon: Icons.local_offer_outlined,
      createdAt: DateTime.now().subtract(
        const Duration(hours: 8),
      ),
      isRead: false,
      relatedJobId: null,
      orderNumber: null,
      hasAction: true,
      route: '/bonus-jobs',
    ),
  ];

  static List<WorkerNotification> get unreadNotifications {
    return notifications.where(
          (notification) => !notification.isRead,
    ).toList();
  }

  static int get unreadCount {
    return unreadNotifications.length;
  }

  static void markAsRead(int notificationId) {
    final index = notifications.indexWhere(
          (notification) => notification.id == notificationId,
    );

    if (index == -1) return;

    notifications[index] = notifications[index].copyWith(
      isRead: true,
    );
  }

  static void markAllAsRead() {
    notifications = notifications.map(
          (notification) {
        return notification.copyWith(
          isRead: true,
        );
      },
    ).toList();
  }

  static void addNotification(
      WorkerNotification notification,
      ) {
    notifications.insert(
      0,
      notification,
    );
  }

  static void removeNotification(
      int notificationId,
      ) {
    notifications.removeWhere(
          (notification) =>
      notification.id == notificationId,
    );
  }

  static List<WorkerNotification> getNotificationsByType(
      String type,
      ) {
    return notifications.where(
          (notification) =>
      notification.type.toLowerCase() ==
          type.toLowerCase(),
    ).toList();
  }
}