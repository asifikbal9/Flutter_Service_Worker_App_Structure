import '../models/bonus_job.dart';

class DemoBonusJobs {
  static List<BonusJob> bonusJobs = [
    BonusJob(
      id: 1,
      title: 'Nearby AC Servicing',
      description:
      'Complete this urgent AC servicing request within the next 2 hours.',
      category: 'Home Appliance',
      address: 'Mirpur, Dhaka',
      latitude: 23.8223,
      longitude: 90.3654,
      distanceKm: 2.4,
      estimatedDuration: const Duration(minutes: 90),
      bonusAmount: 250,
      rewardPoints: 25,
      expiresAt: DateTime.now().add(
        const Duration(hours: 2),
      ),
      assignedWorkerId: null,
      assignedWorkerName: null,
      status: 'Available',
      acceptedAt: null,
      startedAt: null,
      completedAt: null,
      bonusPaid: false,
      bonusPaidAt: null,
      requiresVerification: false,
      verificationType: 'None',
      notes: 'Urgent request.',
    ),

    BonusJob(
      id: 2,
      title: 'Emergency Plumbing',
      description:
      'Customer requires urgent plumbing assistance for water leakage.',
      category: 'Plumbing',
      address: 'Uttara, Dhaka',
      latitude: 23.8759,
      longitude: 90.3795,
      distanceKm: 4.1,
      estimatedDuration: const Duration(minutes: 120),
      bonusAmount: 400,
      rewardPoints: 40,
      expiresAt: DateTime.now().add(
        const Duration(hours: 3),
      ),
      assignedWorkerId: null,
      assignedWorkerName: null,
      status: 'Available',
      acceptedAt: null,
      startedAt: null,
      completedAt: null,
      bonusPaid: false,
      bonusPaidAt: null,
      requiresVerification: false,
      verificationType: 'None',
      notes: 'Water leakage emergency.',
    ),

    BonusJob(
      id: 3,
      title: 'Evening Deep Cleaning',
      description:
      'Take an additional cleaning job to earn extra rewards.',
      category: 'Cleaning',
      address: 'Banani, Dhaka',
      latitude: 23.7937,
      longitude: 90.4066,
      distanceKm: 6.2,
      estimatedDuration: const Duration(minutes: 180),
      bonusAmount: 300,
      rewardPoints: 30,
      expiresAt: DateTime.now().add(
        const Duration(hours: 5),
      ),
      assignedWorkerId: null,
      assignedWorkerName: null,
      status: 'Available',
      acceptedAt: null,
      startedAt: null,
      completedAt: null,
      bonusPaid: false,
      bonusPaidAt: null,
      requiresVerification: false,
      verificationType: 'None',
      notes: 'Extra evening shift.',
    ),

    BonusJob(
      id: 4,
      title: 'Quick Electric Repair',
      description:
      'Customer reported a power outage issue requiring immediate attention.',
      category: 'Electrical',
      address: 'Mohammadpur, Dhaka',
      latitude: 23.7639,
      longitude: 90.3589,
      distanceKm: 1.8,
      estimatedDuration: const Duration(minutes: 60),
      bonusAmount: 200,
      rewardPoints: 20,
      expiresAt: DateTime.now().add(
        const Duration(hours: 1),
      ),
      assignedWorkerId: null,
      assignedWorkerName: null,
      status: 'Available',
      acceptedAt: null,
      startedAt: null,
      completedAt: null,
      bonusPaid: false,
      bonusPaidAt: null,
      requiresVerification: false,
      verificationType: 'None',
      notes: 'Immediate response required.',
    ),

    BonusJob(
      id: 5,
      title: 'Weekend Home Inspection',
      description:
      'Perform a home maintenance inspection and receive a premium bonus.',
      category: 'Inspection',
      address: 'Dhanmondi, Dhaka',
      latitude: 23.7465,
      longitude: 90.3760,
      distanceKm: 8.5,
      estimatedDuration: const Duration(minutes: 240),
      bonusAmount: 600,
      rewardPoints: 60,
      expiresAt: DateTime.now().add(
        const Duration(days: 1),
      ),
      assignedWorkerId: null,
      assignedWorkerName: null,
      status: 'Available',
      acceptedAt: null,
      startedAt: null,
      completedAt: null,
      bonusPaid: false,
      bonusPaidAt: null,
      requiresVerification: true,
      verificationType: 'Photo',
      notes: 'Premium weekend task.',
    ),
  ];

  static List<BonusJob> get availableBonusJobs {
    return bonusJobs.where(
          (job) => job.isAvailable,
    ).toList();
  }

  static List<BonusJob> get completedBonusJobs {
    return bonusJobs.where(
          (job) => job.isCompleted,
    ).toList();
  }

  static double get totalBonusEarned {
    return bonusJobs.where(
          (job) => job.bonusPaid,
    ).fold(
      0,
          (total, job) => total + job.bonusAmount,
    );
  }

  static int get totalPointsEarned {
    return bonusJobs.where(
          (job) => job.bonusPaid,
    ).fold(
      0,
          (total, job) => total + job.rewardPoints,
    );
  }

  static void completeBonusJob(int jobId) {
    final index = bonusJobs.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) {
      return;
    }

    final job = bonusJobs[index];

    bonusJobs[index] = job.copyWith(
      status: 'Completed',
      completedAt: DateTime.now(),
    );
  }

  static void claimBonusJob(int jobId) {
    final index = bonusJobs.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) {
      return;
    }

    final job = bonusJobs[index];

    bonusJobs[index] = job.copyWith(
      bonusPaid: true,
      bonusPaidAt: DateTime.now(),
    );
  }

  static BonusJob? getById(int id) {
    try {
      return bonusJobs.firstWhere(
            (job) => job.id == id,
      );
    } catch (_) {
      return null;
    }
  }
}