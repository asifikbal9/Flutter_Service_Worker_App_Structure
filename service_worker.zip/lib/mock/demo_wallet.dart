import '../models/wallet.dart';
import '../models/wallet_transaction.dart';

class DemoWallet {
  static List<Wallet> wallets = [
    Wallet(
      workerId: 1,
      todayEarnings: 2450,
      availableBalance: 18500,
      pendingBalance: 2200,
      bonusEarned: 3200,
      lifetimeEarnings: 286500,
      totalWithdrawn: 265800,

      monthlyEarnings: 42500,
      monthlyGoal: 50000,

      rewardPoints: 12450,
      completedJobs: 421,
      completedBonusJobs: 28,
      rating: 4.9,
      tier: 'Diamond',
      streakDays: 18,
      cancelledJobs: 2,
      rejectedJobs: 5,
      lateArrivals: 1,

      lastWithdrawalDate:
      DateTime.now().subtract(
        const Duration(days: 3),
      ),

      transactions: [
        WalletTransaction(
          id: 1,
          title: 'Job Payment',
          description: 'AC Servicing',
          amount: 1200,
          type: 'credit',
          createdAt: DateTime.now().subtract(
            const Duration(days: 1),
          ),
          relatedJobId: 1,
        ),
      ],
    ),
  ];

  /// REQUIRED by EarningsProvider
  static Wallet get wallet => wallets.first;

  static Wallet? getWallet(
      int workerId,
      ) {
    try {
      return wallets.firstWhere(
            (wallet) =>
        wallet.workerId == workerId,
      );
    } catch (_) {
      return null;
    }
  }

  static void updateWallet(
      Wallet updatedWallet,
      ) {
    final index = wallets.indexWhere(
          (wallet) =>
      wallet.workerId ==
          updatedWallet.workerId,
    );

    if (index != -1) {
      wallets[index] = updatedWallet;
    }
  }

  static void addEarnings({
    required int workerId,
    required double amount,
  }) {
    final wallet =
    getWallet(workerId);

    if (wallet == null) {
      return;
    }

    final transaction =
    WalletTransaction(
      id: DateTime.now()
          .millisecondsSinceEpoch,
      title: 'Job Earnings',
      description:
      'Service completed',
      amount: amount,
      type: 'credit',
      createdAt: DateTime.now(),
    );

    updateWallet(
      wallet.copyWith(
        todayEarnings:
        wallet.todayEarnings +
            amount,

        availableBalance:
        wallet.availableBalance +
            amount,

        lifetimeEarnings:
        wallet.lifetimeEarnings +
            amount,

        monthlyEarnings:
        wallet.monthlyEarnings +
            amount,

        transactions: [
          transaction,
          ...wallet.transactions,
        ],
      ),
    );
  }

  static void addBonus({
    required int workerId,
    required double amount,
    required int points,
  }) {
    final wallet =
    getWallet(workerId);

    if (wallet == null) {
      return;
    }

    final transaction =
    WalletTransaction(
      id: DateTime.now()
          .millisecondsSinceEpoch,
      title: 'Bonus Reward',
      description:
      'Bonus credited',
      amount: amount,
      type: 'credit',
      createdAt: DateTime.now(),
    );

    updateWallet(
      wallet.copyWith(
        availableBalance:
        wallet.availableBalance +
            amount,

        bonusEarned:
        wallet.bonusEarned +
            amount,

        rewardPoints:
        wallet.rewardPoints +
            points,

        transactions: [
          transaction,
          ...wallet.transactions,
        ],
      ),
    );
  }

  static bool withdraw({
    required int workerId,
    required double amount,
  }) {
    final wallet =
    getWallet(workerId);

    if (wallet == null) {
      return false;
    }

    if (wallet.availableBalance <
        amount) {
      return false;
    }

    final transaction =
    WalletTransaction(
      id: DateTime.now()
          .millisecondsSinceEpoch,
      title: 'Withdrawal',
      description:
      'Wallet withdrawal',
      amount: amount,
      type: 'debit',
      createdAt: DateTime.now(),
    );

    updateWallet(
      wallet.copyWith(
        availableBalance:
        wallet.availableBalance -
            amount,

        totalWithdrawn:
        wallet.totalWithdrawn +
            amount,

        lastWithdrawalDate:
        DateTime.now(),

        transactions: [
          transaction,
          ...wallet.transactions,
        ],
      ),
    );

    return true;
  }
}