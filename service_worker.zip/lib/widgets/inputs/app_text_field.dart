import 'package:flutter/material.dart';

import '../../app/theme.dart';

class AppTextField extends StatelessWidget {
  final TextEditingController? controller;

  final String? label;

  final String? hintText;

  final IconData? prefixIcon;

  final Widget? suffixIcon;

  final TextInputType keyboardType;

  final TextInputAction textInputAction;

  final bool obscureText;

  final bool enabled;

  final bool readOnly;

  final int maxLines;

  final int? maxLength;

  final String? Function(String?)? validator;

  final ValueChanged<String>? onChanged;

  final VoidCallback? onTap;

  final FocusNode? focusNode;

  final EdgeInsetsGeometry? contentPadding;

  final TextCapitalization textCapitalization;

  final bool autofocus;

  const AppTextField({
    super.key,
    this.controller,
    this.label,
    this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.obscureText = false,
    this.enabled = true,
    this.readOnly = false,
    this.maxLines = 1,
    this.maxLength,
    this.validator,
    this.onChanged,
    this.onTap,
    this.focusNode,
    this.contentPadding,
    this.textCapitalization = TextCapitalization.none,
    this.autofocus = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(
        milliseconds: 250,
      ),

      child: TextFormField(
        controller: controller,

        focusNode: focusNode,

        autofocus: autofocus,

        enabled: enabled,

        readOnly: readOnly,

        obscureText: obscureText,

        keyboardType: keyboardType,

        textInputAction: textInputAction,

        maxLines: obscureText
            ? 1
            : maxLines,

        maxLength: maxLength,

        validator: validator,

        onChanged: onChanged,

        onTap: onTap,

        textCapitalization:
        textCapitalization,

        style: const TextStyle(
          fontSize: 16,

          fontWeight:
          FontWeight.w500,

          color:
          AppTheme.textPrimary,
        ),

        decoration: InputDecoration(
          labelText: label,

          hintText: hintText,

          counterText: '',

          prefixIcon: prefixIcon != null
              ? Icon(
            prefixIcon,

            color: AppTheme
                .textSecondary,
          )
              : null,

          suffixIcon: suffixIcon,

          contentPadding:
          contentPadding ??
              const EdgeInsets
                  .symmetric(
                horizontal: 20,
                vertical: 18,
              ),

          filled: true,

          fillColor: enabled
              ? Colors.white
              : Colors.grey.shade100,

          border: OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide:
            const BorderSide(
              color:
              AppTheme.borderColor,
            ),
          ),

          enabledBorder:
          OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide:
            const BorderSide(
              color:
              AppTheme.borderColor,
            ),
          ),

          focusedBorder:
          OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide:
            const BorderSide(
              color:
              AppTheme.primaryColor,

              width: 2,
            ),
          ),

          errorBorder:
          OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide:
            const BorderSide(
              color:
              AppTheme.errorColor,
            ),
          ),

          focusedErrorBorder:
          OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide:
            const BorderSide(
              color:
              AppTheme.errorColor,

              width: 2,
            ),
          ),

          disabledBorder:
          OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            borderSide: BorderSide(
              color:
              Colors.grey.shade300,
            ),
          ),

          labelStyle: const TextStyle(
            color:
            AppTheme.textSecondary,
          ),

          hintStyle: TextStyle(
            color: Colors.grey.shade500,
          ),
        ),
      ),
    );
  }
}